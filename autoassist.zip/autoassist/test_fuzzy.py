"""Sanity tests + a few worked examples for the fuzzy systems."""
from datetime import datetime, timedelta

from app.fuzzy import fuzzy_priority, priority_label, reminder_interval
from app.priority import email_priority

NOW = datetime(2026, 11, 16, 10, 0)

print("=== Priority examples (deadline hours, importance, waiting hours) ===")
cases = [("Urgent, important sender, deadline in 5 h", 5, 8, 2),
         ("Task from university, deadline in 2 days", 48, 8, 10),
         ("Friend asks to meet next week", 150, 5, 5),
         ("Newsletter-like sender, no deadline", 168, 1, 0),
         ("Important sender, no deadline, waiting 60 h", 168, 9, 60)]
scores = {}
for name, d, i, w in cases:
    s, fired = fuzzy_priority(d, i, w)
    scores[name] = s
    print(f"{name:48} -> {s:5.1f}  {priority_label(s)}")

s, fired = fuzzy_priority(5, 8, 2)
print("\nWhy is the first case high? Rules that fired:")
for strength, rule in fired[:4]:
    print(f"  {strength:.2f}  IF {rule}")

assert scores[cases[0][0]] > scores[cases[1][0]] > scores[cases[2][0]] > scores[cases[3][0]], scores
assert all(0 <= v <= 100 for v in scores.values())
assert fuzzy_priority(1, 10, 0)[0] > fuzzy_priority(150, 10, 0)[0]
assert fuzzy_priority(20, 9, 0)[0] > fuzzy_priority(20, 2, 0)[0]
print("\nPriority ordering tests: PASS")

print("\n=== Reminder interval (minutes) as the deadline gets closer, priority 80 ===")
prev = None
for h in (120, 72, 48, 24, 12, 6, 2, 0):
    v = reminder_interval(h, 80)
    print(f"  {h:>3} h left -> every {v} min")
    assert prev is None or v <= prev, "interval must not grow as the deadline approaches"
    prev = v
assert reminder_interval(2, 90) < reminder_interval(2, 10)
print("Reminder tests: PASS")

print("\n=== Whole-email examples ===")
emails = [("Prof <prof@iqra.edu.pk>", "Lab report due", "Please submit the lab report by tomorrow 5 pm.", "task", NOW - timedelta(hours=3)),
          ("Ali <ali@gmail.com>", "URGENT", "Reply asap, server is down", "urgent", NOW - timedelta(hours=1)),
          ("Hina <hina@gmail.com>", "Hello", "Sharing the class notes", "general", NOW - timedelta(hours=30)),
          ("Pin <noreply@pinterest.com>", "Flawless", "Ideas you will love", "spam", NOW)]
for sender, subj, body, cat, rec in emails:
    r = email_priority(sender, subj, body, cat, rec, NOW)
    print(f"{subj:15} [{cat:7}] score {r['score']:5.1f} {r['label']:6} inputs {r['inputs']}")
