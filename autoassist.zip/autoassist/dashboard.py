"""AutoAssist dashboard (Streamlit): accounts, per-user Gmail connection and the full workflow in the browser."""
import html
import traceback
from datetime import datetime, timedelta

import pandas as pd
import plotly.graph_objects as go
import streamlit as st
from sqlalchemy import text

from app import pipeline
from app.accounts import AccountError, authenticate, change_password, create_user, get_user, registration_code_required, update_name
from app.calendar_service import get_busy
from app.db import engine
from app.fuzzy import priority_label
from app.google_auth import GoogleAuthError, connection_status, disconnect, finish_oauth, start_oauth
from app.reminders import add_reminder, list_reminders, mark_done

st.set_page_config(page_title="AutoAssist", page_icon="⚡", layout="wide")

# ------------------------------------------------------------------ theme
TEAL, BLUE, ORANGE, NAVY, GREEN, GREY = (
    "#0aa5a8", "#1c78b2", "#f5a31a", "#3440a8", "#8cc63f", "#b8c2cf")
INK = "#1f2a44"
BOLT = ('<svg viewBox="0 0 24 24" width="26" height="26" fill="none" stroke="#fff" '
        'stroke-width="2" stroke-linecap="round" stroke-linejoin="round">'
        '<path d="M13 2 3 14h7l-1 8 10-12h-7z"/></svg>')

CSS_COMMON = """
<style>
#MainMenu, footer {visibility: hidden;}
header[data-testid="stHeader"] {background: transparent;}
html, body, .stApp {font-family: 'Segoe UI', system-ui, -apple-system, Roboto, Helvetica, Arial, sans-serif;}
.block-container {padding: 1.5rem 2rem 3rem; max-width: 1400px;}
[data-testid="stForm"] button, .stApp .stButton button[kind="primary"] {background: linear-gradient(135deg, #0aa5a8, #1c78b2); color: #fff; border: none; border-radius: 10px; font-weight: 600; padding: .6rem 1rem;}
[data-testid="stForm"] button p, .stApp .stButton button[kind="primary"] p {color: #fff;}
[data-testid="stForm"] button {width: 100%;}
.stApp .stButton button {border-radius: 10px;}
div[data-baseweb="input"], div[data-baseweb="base-input"], div[data-baseweb="textarea"] {border-radius: 10px;}
@media (max-width: 768px) {
  .block-container {padding: 1rem .8rem 2rem;}
}
</style>
"""

CSS_LOGIN = """
<style>
.stApp {background: linear-gradient(135deg, #079fa5 0%, #1c78b2 100%);}
.block-container {max-width: 460px; padding-top: 7vh;}
[data-testid="stForm"] {background: #fff; border: 1px solid rgba(255,255,255,.7); border-radius: 20px; padding: 28px 26px; box-shadow: 0 20px 50px rgba(8,50,90,.35);}
.login-logo {text-align: center; margin-bottom: 22px;}
.logo-badge {width: 64px; height: 64px; margin: 0 auto 12px; border-radius: 18px; background: rgba(255,255,255,.2); border: 1px solid rgba(255,255,255,.45); display: grid; place-items: center;}
.logo-badge svg {width: 34px; height: 34px;}
.logo-text {color: #fff; font-size: 2rem; font-weight: 800; letter-spacing: .3px;}
.logo-sub {color: rgba(255,255,255,.85); font-size: .95rem; margin-top: 2px;}
.login-foot {text-align: center; color: rgba(255,255,255,.8); font-size: .8rem; margin-top: 18px;}
.form-title {font-size: 1.25rem; font-weight: 700; color: #1f2a44; margin-bottom: 2px;}
.form-sub {color: #7a8699; font-size: .9rem; margin-bottom: 8px;}
@media (max-width: 480px) {
  .block-container {padding-top: 4vh;}
  .logo-text {font-size: 1.7rem;}
  [data-testid="stForm"] {padding: 22px 18px;}
}
</style>
"""

CSS_APP = """
<style>
section[data-testid="stSidebar"] {background: linear-gradient(180deg, #079fa5 0%, #1c78b2 52%, #079fa5 100%); border-right: none;}
section[data-testid="stSidebar"] * {color: #fff;}
section[data-testid="stSidebar"] .stButton button {width: 100%; justify-content: flex-start; background: transparent !important; border: none !important; color: #fff !important; border-radius: 12px; padding: .6rem .9rem; font-weight: 500; box-shadow: none;}
section[data-testid="stSidebar"] .stButton button:hover {background: rgba(255,255,255,.16) !important;}
section[data-testid="stSidebar"] .stButton button[kind="primary"] {background: #fff !important; color: #0b6f8f !important; font-weight: 700;}
section[data-testid="stSidebar"] .stButton button[kind="primary"] * {color: #0b6f8f !important;}
section[data-testid="stSidebar"] .stButton button p {text-align: left;}
.side-logo {display: flex; align-items: center; gap: 10px; padding: 6px 4px 18px;}
.side-logo .badge {width: 42px; height: 42px; border-radius: 12px; background: rgba(255,255,255,.2); display: grid; place-items: center;}
.side-logo .name {font-size: 1.35rem; font-weight: 800;}
.side-user {display: flex; align-items: center; gap: 10px; padding: 14px 6px 8px; border-top: 1px solid rgba(255,255,255,.25); margin-top: 24px;}
.side-user .av {width: 38px; height: 38px; border-radius: 50%; background: rgba(255,255,255,.25); display: grid; place-items: center; font-weight: 700;}
.side-user .nm {font-weight: 600; line-height: 1.1;}
.side-user .rl {font-size: .78rem; opacity: .8;}
.page-head {display: flex; justify-content: space-between; align-items: baseline; flex-wrap: wrap; gap: 6px; margin-bottom: 14px;}
.page-head h1 {margin: 0; padding: 0; font-size: 1.8rem; color: #1f2a44; font-weight: 800;}
.page-head span {color: #7a8699; font-size: .9rem;}
[class*="st-key-card_"] {background: #fff; border: 1px solid #e3e9f0; border-radius: 18px; padding: 18px 20px; box-shadow: 0 6px 20px rgba(28,120,178,.08);}
[data-testid="stForm"] {background: #fff; border: 1px solid #e3e9f0; border-radius: 18px; padding: 18px 20px; box-shadow: 0 6px 20px rgba(28,120,178,.08);}
.card-title {font-size: 1.05rem; font-weight: 700; color: #1f2a44;}
.card-sub {font-size: .82rem; color: #7a8699; margin-bottom: 6px;}
.top-grid {display: grid; grid-template-columns: minmax(230px, 300px) 1fr; gap: 16px; margin-bottom: 18px;}
.profile {display: flex; align-items: center; gap: 14px; background: #fff; border: 1px solid #e3e9f0; border-radius: 18px; padding: 16px 18px; box-shadow: 0 6px 20px rgba(28,120,178,.08);}
.avatar {flex: 0 0 56px; width: 56px; height: 56px; border-radius: 50%; background: linear-gradient(135deg, #0aa5a8, #1c78b2); color: #fff; display: grid; place-items: center; font-weight: 800; font-size: 1.4rem;}
.p-name {font-weight: 700; font-size: 1.1rem; color: #1f2a44; word-break: break-word;}
.p-sub {color: #7a8699; font-size: .85rem;}
.kpi-grid {display: grid; grid-template-columns: repeat(auto-fit, minmax(150px, 1fr)); gap: 14px;}
.kpi {border-radius: 16px; padding: 14px 18px; color: #fff; box-shadow: 0 8px 18px rgba(31,42,68,.14);}
.kpi-label {font-size: .85rem; opacity: .95; font-weight: 600;}
.kpi-val {font-size: 2rem; font-weight: 800; line-height: 1.15; margin-top: 4px;}
.ring-wrap {display: flex; justify-content: center; padding: 10px 0 4px;}
.ring {width: 128px; height: 128px; border-radius: 50%; display: grid; place-items: center;}
.ring-in {width: 94px; height: 94px; border-radius: 50%; background: #fff; display: grid; place-items: center; font-size: 1.5rem; font-weight: 800; color: #1f2a44;}
.ring-cap {text-align: center; color: #7a8699; font-size: .85rem;}
.tbl-wrap {overflow-x: auto; border: 1px solid #e3e9f0; border-radius: 14px; background: #fff;}
.tbl {width: 100%; border-collapse: collapse; font-size: .9rem; color: #1f2a44;}
.tbl th {background: #f2f7fb; color: #4a5a73; text-align: left; padding: 11px 14px; white-space: nowrap; font-weight: 700;}
.tbl td {padding: 11px 14px; border-top: 1px solid #eef2f6; white-space: nowrap; max-width: 320px; overflow: hidden; text-overflow: ellipsis;}
.tbl tr:hover td {background: #f8fbfd;}
.empty {color: #7a8699; padding: 22px; text-align: center; background: #fff; border: 1px dashed #cfd9e4; border-radius: 14px;}
.pill {display: inline-block; padding: 2px 10px; border-radius: 999px; font-size: .78rem; font-weight: 700;}
.p-orange {background: #fff1d9; color: #b86e00;} .p-teal {background: #d9f5f5; color: #067a7d;}
.p-navy {background: #e3e5fa; color: #3440a8;} .p-blue {background: #dcecf8; color: #1c78b2;}
.p-green {background: #e8f5d6; color: #4d7a12;} .p-red {background: #fde2e4; color: #b3261e;}
.p-grey {background: #eceff3; color: #5d6b7d;}
.item-head {font-weight: 700; color: #1f2a44; word-break: break-word;}
.item-meta {color: #7a8699; font-size: .85rem; margin-bottom: 8px; word-break: break-word;}
.rem-text {color: #1f2a44; word-break: break-word;}
@media (max-width: 768px) {
  .top-grid {grid-template-columns: 1fr;}
  .page-head h1 {font-size: 1.4rem;}
  .kpi-val {font-size: 1.6rem;}
  [class*="st-key-card_"] {padding: 14px;}
}
</style>
"""

PILLS = {"urgent": "p-orange", "meeting": "p-teal", "task": "p-navy", "general": "p-blue",
         "spam": "p-grey", "new": "p-blue", "drafted": "p-navy", "replied": "p-green",
         "ignored": "p-grey", "rejected": "p-red", "sent": "p-green", "pending": "p-orange",
         "critical": "p-red", "high": "p-orange", "medium": "p-blue", "low": "p-grey",
         "ai": "p-teal", "template": "p-grey"}
CAT_COLORS = {"general": BLUE, "meeting": TEAL, "urgent": ORANGE, "task": NAVY, "spam": GREY}



CSS_EXTRA = """
<style>
.conn {display: flex; align-items: center; gap: 10px; flex-wrap: wrap; margin-bottom: 8px;}
.dot {width: 10px; height: 10px; border-radius: 50%; display: inline-block;}
.note {color: #7a8699; font-size: .85rem; line-height: 1.5;}
.effort {font-size: .85rem; color: #4a5a73; background: #f2f7fb; border-radius: 10px; padding: 8px 12px; margin: 6px 0 10px;}
.stTabs [data-baseweb="tab-list"] {gap: 6px;}
.st-key-signout_top button {background: #fff; color: #1c78b2; border: 1.5px solid #1c78b2; font-weight: 700; width: 100%;}
.st-key-signout_top button:hover {background: #1c78b2; color: #fff; border-color: #1c78b2;}
.st-key-signout_top button:hover p {color: #fff;}
section[data-testid="stSidebar"] .st-key-signout button {border: 1.5px solid rgba(255,255,255,.85) !important; justify-content: center; font-weight: 700;}
section[data-testid="stSidebar"] .st-key-signout button:hover {background: rgba(255,255,255,.22) !important;}
</style>
"""
# ------------------------------------------------------------------ helpers
def esc(v):
    return html.escape(str(v), quote=True)


def q(sql, params=None):
    with engine.connect() as conn:
        return pd.read_sql(text(sql), conn, params=params or {})


def run(sql, params=None):
    with engine.begin() as conn:
        conn.execute(text(sql), params or {})


def count(sql):
    return int(q(sql).iloc[0, 0])


def uid():
    return st.session_state["user_id"]


def log(action, details=""):
    run("INSERT INTO ActivityLog (user_id, action, details) VALUES (:u, :a, :d)",
        {"u": uid(), "a": action, "d": details})


def fmt(v):
    if v is None or pd.isna(v):
        return ""
    if isinstance(v, (datetime, pd.Timestamp)):
        return v.strftime("%d %b %Y, %I:%M %p")
    return str(v)


def pill(value):
    cls = PILLS.get(str(value).lower(), "p-grey")
    return f'<span class="pill {cls}">{esc(value)}</span>'


def html_table(df, max_rows=100):
    """Responsive table. Every cell is HTML-escaped because email text is untrusted."""
    if df.empty:
        return '<div class="empty">No data yet.</div>'
    head = "".join(f"<th>{esc(c)}</th>" for c in df.columns)
    body = ""
    for _, row in df.head(max_rows).iterrows():
        cells = ""
        for col, val in row.items():
            if col in ("Category", "Status", "Priority") and fmt(val):
                cells += f"<td>{pill(fmt(val))}</td>"
            else:
                cells += f"<td>{esc(fmt(val))}</td>"
        body += f"<tr>{cells}</tr>"
    return f'<div class="tbl-wrap"><table class="tbl"><thead><tr>{head}</tr></thead><tbody>{body}</tbody></table></div>'


def card(name):
    return st.container(key=f"card_{name}")


def card_title(title, sub=""):
    st.markdown(f'<div class="card-title">{title}</div><div class="card-sub">{sub}</div>',
                unsafe_allow_html=True)


def sign_out():
    """Ends the session: everything kept in the browser session is deleted. The Gmail connection stays in the database."""
    st.session_state.clear()
    st.rerun()


def page_head(title):
    left, right = st.columns([5, 1.2], vertical_alignment="center")
    left.markdown(f'<div class="page-head"><h1>{title}</h1>'
                  f'<span>{datetime.now():%A, %d %B %Y}</span></div>', unsafe_allow_html=True)
    if right.button("Sign out", key="signout_top", icon=":material/logout:"):
        sign_out()


def flash(msg, warnings=None):
    st.session_state["flash"] = msg
    st.session_state["flash_warn"] = warnings or []


def show_flash():
    msg = st.session_state.pop("flash", None)
    if msg:
        st.success(msg)
    for w in st.session_state.pop("flash_warn", []):
        st.warning(w)


def style_fig(fig, height=270):
    fig.update_layout(height=height, margin=dict(l=8, r=8, t=8, b=8),
                      paper_bgcolor="rgba(0,0,0,0)", plot_bgcolor="rgba(0,0,0,0)",
                      font=dict(family="Segoe UI, Arial", color="#4a5a73"),
                      legend=dict(orientation="h", y=-0.12, x=0.5, xanchor="center"))
    fig.update_xaxes(showgrid=False, showline=False, zeroline=False)
    fig.update_yaxes(gridcolor="#edf1f6", zeroline=False, rangemode="tozero")
    return fig


def show_fig(fig, key):
    st.plotly_chart(fig, key=key, config={"displayModeBar": False})


def daily_counts(sql, days):
    df = q(sql, {"u": uid()})
    idx = pd.date_range(end=pd.Timestamp.today().normalize(), periods=days)
    if df.empty:
        return pd.DataFrame({"d": idx, "n": 0})
    s = pd.Series(df["n"].values, index=pd.to_datetime(df["d"]))
    return pd.DataFrame({"d": idx, "n": s.reindex(idx, fill_value=0).values})




# ------------------------------------------------------------------ session and login
def sign_in(user):
    st.session_state.clear()
    st.session_state.update(user=user["name"], user_id=user["user_id"], user_email=user["email"],
                            role=user["role"], page="Dashboard")


def handle_google_callback():
    """Google sends the browser back here with ?code=...&state=... after the user clicked Allow."""
    params = st.query_params
    if "state" not in params or ("code" not in params and "error" not in params):
        return
    state, code, error = params.get("state"), params.get("code"), params.get("error")
    result = None
    if error:
        result = ("error", "Google sign-in was cancelled. Nothing was connected.")
    else:
        try:
            user_id, address = finish_oauth(state, code)
            sign_in(get_user(user_id))
            st.session_state["page"] = "Settings"
            result = ("ok", f"Gmail connected: {address}")
        except GoogleAuthError as exc:
            result = ("error", str(exc))
    st.query_params.clear()
    st.session_state["oauth_result"] = result
    st.rerun()


def login_page():
    st.markdown(CSS_LOGIN, unsafe_allow_html=True)
    st.markdown(f'<div class="login-logo"><div class="logo-badge">{BOLT}</div>'
                '<div class="logo-text">AutoAssist</div>'
                '<div class="logo-sub">Your AI-powered personal assistant</div></div>', unsafe_allow_html=True)
    result = st.session_state.pop("oauth_result", None)
    if result:
        (st.success if result[0] == "ok" else st.error)(result[1])
    tab_in, tab_up = st.tabs(["Sign in", "Create account"])
    with tab_in:
        with st.form("login_form"):
            st.markdown('<div class="form-title">Welcome back</div><div class="form-sub">Sign in to continue</div>',
                        unsafe_allow_html=True)
            email = st.text_input("Email", placeholder="you@example.com")
            pw = st.text_input("Password", type="password", placeholder="Your password")
            submitted = st.form_submit_button("Sign in")
        if submitted:
            try:
                sign_in(authenticate(email, pw))
                run("INSERT INTO ActivityLog (user_id, action, details) VALUES (:u, 'login', :d)",
                    {"u": st.session_state["user_id"], "d": st.session_state["user_email"]})
                st.rerun()
            except AccountError as exc:
                st.error(str(exc))
    with tab_up:
        with st.form("register_form"):
            st.markdown('<div class="form-title">Create your account</div>'
                        '<div class="form-sub">Your login email can be any email. You connect your Gmail later in Settings.</div>',
                        unsafe_allow_html=True)
            name = st.text_input("Full name")
            email2 = st.text_input("Email (your login)", placeholder="you@example.com")
            pw1 = st.text_input("Password (at least 8 characters)", type="password")
            pw2 = st.text_input("Confirm password", type="password")
            code = st.text_input("Registration code") if registration_code_required() else ""
            created = st.form_submit_button("Create account")
        if created:
            if pw1 != pw2:
                st.error("The two passwords do not match.")
            else:
                try:
                    create_user(name, email2, pw1, code=code)
                    sign_in(authenticate(email2, pw1))
                    flash("Account created. Next step: connect your Gmail in Settings.")
                    st.rerun()
                except AccountError as exc:
                    st.error(str(exc))
    st.markdown('<div class="login-foot">AI Lab Project &middot; Iqra University</div>', unsafe_allow_html=True)


# ------------------------------------------------------------------ pages
def gmail_connected():
    return connection_status(uid()) is not None


def goto_page(page):
    st.session_state["page"] = page
    st.rerun()


def _fail(exc):
    if isinstance(exc, GoogleAuthError):
        st.error(str(exc))
    else:
        st.error(f"Something went wrong: {exc}")
        with st.expander("Technical details (copy this if the problem continues)"):
            st.code(traceback.format_exc())


def run_sync():
    """Only reads the inbox. Writing replies is a separate button."""
    with st.spinner("Reading your inbox..."):
        try:
            s = pipeline.sync_inbox(uid())
        except Exception as exc:
            _fail(exc)
            return
    hint = " Press 'Write reply drafts' to prepare replies." if s["new"] else ""
    flash(f"{s['new']} new emails read ({s['fetched']} checked).{hint}")
    st.rerun()


def run_drafts():
    """Writes replies for the emails that do not have one yet, and explains what it skipped."""
    with st.spinner("Writing replies with AI. This takes a few seconds per email..."):
        try:
            r = pipeline.generate_drafts(uid())
        except Exception as exc:
            _fail(exc)
            return
    warnings = list(r["notes"])
    if r["considered"] == 0:
        msg = "No new emails are waiting for a reply draft. Press 'Sync inbox' to fetch new ones."
    else:
        msg = f"{r['made']} reply drafts written ({r['llm']} by AI, {r['templates']} from templates)."
        skipped = []
        if r["skipped_spam"]:
            skipped.append(f"{r['skipped_spam']} promotional or automated")
        if r["skipped_noreply"]:
            skipped.append(f"{r['skipped_noreply']} from no-reply addresses")
        if skipped:
            msg += " Skipped because they need no reply: " + ", ".join(skipped) + "."
        if r["made"] == 0:
            warnings.append("Nothing needed a reply. To answer any email anyway, open the Emails page and press 'Write reply' on it.")
    if r["left"]:
        warnings.append(f"{r['left']} more emails are waiting. Press 'Write reply drafts' again to continue.")
    flash(msg, warnings)
    if r["made"]:
        st.session_state["page"] = "Pending drafts"
    st.rerun()


def dashboard_page():
    page_head("Dashboard")
    show_flash()
    connected = gmail_connected()
    if not connected:
        st.info("Connect your Gmail account to start. AutoAssist can then read your inbox, draft replies, "
                "find meeting times and set reminders, and it never sends anything without your approval.")
        if st.button("Open Settings", type="primary", key="to_settings"):
            goto_page("Settings")
    else:
        b1, b2, _ = st.columns([1.3, 1.5, 3])
        if b1.button("Sync inbox", type="primary", key="sync", icon=":material/sync:"):
            run_sync()
        if b2.button("Write reply drafts", key="draft_all", icon=":material/edit_note:"):
            run_drafts()
    due = [r for r in list_reminders(user_id=uid()) if r.deadline <= datetime.now() + timedelta(hours=24)]
    for r in due[:3]:
        st.warning(f"Reminder: {r.task} (due {r.deadline:%a %d %b, %I:%M %p})")

    p = {"u": uid()}
    total = int(q("SELECT COUNT(*) FROM Emails WHERE user_id = :u", p).iloc[0, 0])
    pending = int(q("SELECT COUNT(*) FROM Drafts WHERE user_id = :u AND status='pending'", p).iloc[0, 0])
    sent = int(q("SELECT COUNT(*) FROM Drafts WHERE user_id = :u AND status='sent'", p).iloc[0, 0])
    rejected = int(q("SELECT COUNT(*) FROM Drafts WHERE user_id = :u AND status='rejected'", p).iloc[0, 0])
    meetings = int(q("SELECT COUNT(*) FROM Meetings WHERE user_id = :u", p).iloc[0, 0])
    reminders = int(q("SELECT COUNT(*) FROM Reminders WHERE user_id = :u AND status='active'", p).iloc[0, 0])
    name = st.session_state["user"]

    kpis = [("Emails received", total, ORANGE, "#f8c45f"), ("Drafts pending", pending, NAVY, "#5863c9"),
            ("Replies sent", sent, TEAL, "#37c4c0"), ("Meetings scheduled", meetings, BLUE, "#4a9bd0"),
            ("Active reminders", reminders, "#6fae1f", GREEN)]
    kpi_html = "".join(
        f'<div class="kpi" style="background:linear-gradient(135deg,{a},{b})">'
        f'<div class="kpi-label">{lab}</div><div class="kpi-val">{val}</div></div>' for lab, val, a, b in kpis)
    st.markdown(f'<div class="top-grid"><div class="profile"><div class="avatar">{esc(name[:1].upper())}</div>'
                f'<div><div class="p-name">{esc(name)}</div><div class="p-sub">{esc(st.session_state["user_email"])}</div></div></div>'
                f'<div class="kpi-grid">{kpi_html}</div></div>', unsafe_allow_html=True)

    c1, c2 = st.columns([2, 1], gap="medium")
    with c1:
        with card("daily"):
            card_title("Emails per day", "Last 14 days")
            df = daily_counts("""SELECT CAST(received_at AS DATE) AS d, COUNT(*) AS n FROM Emails
                WHERE user_id = :u AND received_at IS NOT NULL AND received_at >= DATEADD(day, -13, CAST(GETDATE() AS DATE))
                GROUP BY CAST(received_at AS DATE)""", 14)
            fig = go.Figure(go.Scatter(
                x=df["d"], y=df["n"], mode="lines+markers", fill="tozeroy",
                line=dict(color=ORANGE, width=3, shape="spline"), marker=dict(size=7, color=ORANGE),
                fillcolor="rgba(245,163,26,0.18)", hovertemplate="%{x|%d %b}: %{y} emails<extra></extra>"))
            fig.update_xaxes(tickformat="%d %b")
            show_fig(style_fig(fig), "chart_daily")
    with c2:
        with card("cats"):
            card_title("Email categories", "Share of all emails")
            cats = q("SELECT ISNULL(category, 'general') AS category, COUNT(*) AS total FROM Emails WHERE user_id = :u GROUP BY category", p)
            if cats.empty:
                st.markdown('<div class="empty">No emails yet.</div>', unsafe_allow_html=True)
            else:
                fig = go.Figure(go.Pie(labels=cats["category"], values=cats["total"], hole=0.68, textinfo="none", sort=False,
                                       marker=dict(colors=[CAT_COLORS.get(c, GREY) for c in cats["category"]])))
                fig.add_annotation(text=f"<b>{total}</b>", x=0.5, y=0.5, xref="paper", yref="paper",
                                   showarrow=False, font=dict(size=26, color=INK))
                show_fig(style_fig(fig), "chart_cats")

    handled = sent + rejected
    drafts_total = handled + pending
    approval = round(100 * sent / handled) if handled else 0
    handled_pct = round(100 * handled / drafts_total) if drafts_total else 0
    r1, r2, r3 = st.columns([1, 1, 2], gap="medium")
    for col, key, title, sub, pct, color, cap in [
            (r1, "ring_a", "Approval rate", "Sent vs rejected", approval, ORANGE, f"{sent} sent, {rejected} rejected"),
            (r2, "ring_b", "Drafts handled", "Reviewed so far", handled_pct, GREEN, f"{handled} of {drafts_total} drafts")]:
        with col:
            with card(key):
                card_title(title, sub)
                st.markdown(f'<div class="ring-wrap"><div class="ring" style="background:conic-gradient({color} 0 {pct}%, #e6ecf3 {pct}% 100%)">'
                            f'<div class="ring-in">{pct}%</div></div></div><div class="ring-cap">{cap}</div>', unsafe_allow_html=True)
    with r3:
        with card("activity"):
            card_title("System activity", "Actions in the last 7 days")
            df = daily_counts("""SELECT CAST(logged_at AS DATE) AS d, COUNT(*) AS n FROM ActivityLog
                WHERE user_id = :u AND logged_at >= DATEADD(day, -6, CAST(GETDATE() AS DATE))
                GROUP BY CAST(logged_at AS DATE)""", 7)
            fig = go.Figure(go.Scatter(x=df["d"], y=df["n"], mode="lines+markers",
                                       line=dict(color=TEAL, width=3, shape="spline"), marker=dict(size=7, color=TEAL),
                                       hovertemplate="%{x|%d %b}: %{y} actions<extra></extra>"))
            fig.update_xaxes(tickformat="%d %b")
            show_fig(style_fig(fig, 215), "chart_activity")


def emails_page():
    page_head("Emails")
    show_flash()
    p = {"u": uid()}
    cats = q("SELECT DISTINCT ISNULL(category, 'general') AS c FROM Emails WHERE user_id = :u ORDER BY c", p)["c"].tolist()
    choice = st.selectbox("Category", ["All"] + cats)
    if st.session_state.get("email_filter") != choice:
        st.session_state["email_filter"], st.session_state["email_limit"] = choice, 20
    limit = st.session_state.setdefault("email_limit", 20)
    rows, total = pipeline.list_emails(uid(), None if choice == "All" else choice, limit)
    if not rows:
        st.markdown('<div class="empty">No emails yet. Press "Sync inbox" on the Dashboard.</div>', unsafe_allow_html=True)
        return
    pending_ids = pipeline.pending_email_ids(uid())
    st.caption(f"Showing {len(rows)} of {total}. Press 'Write reply' on any email to get a draft for it, even if it was skipped.")
    for e in rows:
        eid = int(e.email_id)
        with card(f"mail_{eid}"):
            score = None if e.priority_score is None or pd.isna(e.priority_score) else float(e.priority_score)
            prio = f" {pill(priority_label(score))}" if score is not None else ""
            got = fmt(e.received_at)
            st.markdown(f'<div class="item-head">{esc(e.subject or "(no subject)")} {pill(e.category or "general")}{prio} {pill(e.status or "new")}</div>'
                        f'<div class="item-meta">From: {esc(e.sender)}{" &middot; " + esc(got) if got else ""}</div>', unsafe_allow_html=True)
            if e.status == "replied":
                st.caption("You already replied to this email.")
            elif eid in pending_ids:
                st.caption("A reply draft is ready.")
                if st.button("Open the draft", key=f"od{eid}"):
                    goto_page("Pending drafts")
            else:
                skipped = e.status == "ignored" or e.category == "spam"
                if st.button("Write reply", key=f"wr{eid}", type="secondary" if skipped else "primary", icon=":material/edit_note:"):
                    with st.spinner("Writing the reply..."):
                        try:
                            res = pipeline.draft_for_email(uid(), eid)
                        except Exception as exc:
                            _fail(exc)
                        else:
                            flash("Reply drafted. Check it below, edit if you like, then approve.",
                                  [res["note"]] if res["note"] else [])
                            st.session_state["page"] = "Pending drafts"
                            st.rerun()
    if total > limit and st.button("Show more", key="more_emails"):
        st.session_state["email_limit"] = limit + 20
        st.rerun()


def drafts_page():
    page_head("Pending drafts")
    show_flash()
    st.caption("Sorted by fuzzy-logic priority: the most important and most urgent emails come first.")
    if st.button("Write replies for new emails", key="draft_top", type="primary", icon=":material/edit_note:"):
        run_drafts()
    rows = pipeline.pending_drafts(uid())
    if not rows:
        s = pipeline.email_summary(uid())
        if s["total"] == 0:
            why = "You have no emails yet. Press 'Sync inbox' on the Dashboard first."
        else:
            why = (f"Of your {s['total']} emails: {s['waiting']} are waiting for a draft (press the button above), "
                   f"{s['skipped']} were skipped because they look promotional, automated or come from no-reply addresses, "
                   f"{s['drafted']} already have a draft and {s['replied']} are replied. "
                   "To answer a skipped email anyway, open the Emails page and press 'Write reply' on it.")
        st.markdown(f'<div class="empty">No pending drafts. {esc(why)}</div>', unsafe_allow_html=True)
        return
    for d in rows:
        did = int(d.draft_id)
        with card(f"draft_{did}"):
            score = None if d.priority_score is None or pd.isna(d.priority_score) else float(d.priority_score)
            prio = f" {pill(priority_label(score))}" if score is not None else ""
            made_by = pill("AI") if d.generated_by == "llm" else pill("Template")
            score_txt = f" &middot; priority score {score:.0f}" if score is not None else ""
            st.markdown(f'<div class="item-head">{esc(d.subject or "(no subject)")} {pill(d.category or "general")}{prio} {made_by}</div>'
                        f'<div class="item-meta">From: {esc(d.sender)}{score_txt}</div>', unsafe_allow_html=True)
            reply = st.text_area("Reply", d.reply_text, key=f"t{did}", height=170)
            b1, b2 = st.columns(2)
            if b1.button("Approve and send", key=f"s{did}", type="primary"):
                try:
                    pipeline.approve_draft(uid(), did, reply)
                except GoogleAuthError as exc:
                    st.error(str(exc))
                except Exception as exc:
                    st.error(f"Could not send: {exc}")
                    with st.expander("Technical details"):
                        st.code(traceback.format_exc())
                else:
                    flash("Reply sent.")
                    st.rerun()
            if b2.button("Reject", key=f"r{did}"):
                pipeline.reject_draft(uid(), did)
                flash("Draft rejected.")
                st.rerun()


def load_meeting_items():
    try:
        busy = get_busy(21, user_id=uid())
    except GoogleAuthError as exc:
        st.session_state["meet_items"] = None
        st.session_state["meet_error"] = str(exc)
        return
    except Exception as exc:
        st.session_state["meet_items"] = None
        st.session_state["meet_error"] = f"Could not read your calendar: {exc}"
        return
    st.session_state["meet_error"] = None
    st.session_state["meet_items"] = pipeline.meeting_requests(uid(), busy)


def meetings_page():
    page_head("Meetings")
    show_flash()
    if "meet_items" not in st.session_state and gmail_connected():
        with st.spinner("Checking your calendar..."):
            load_meeting_items()
    with card("meet_requests"):
        card_title("Meeting requests", "Emails asking for a meeting. The best slots are found with search (BFS, DFS, A*, Weighted A*).")
        if not gmail_connected():
            st.markdown('<div class="empty">Connect your Gmail in Settings to see meeting requests.</div>', unsafe_allow_html=True)
        else:
            if st.button("Refresh requests", key="meet_refresh"):
                load_meeting_items()
                st.rerun()
            if st.session_state.get("meet_error"):
                st.error(st.session_state["meet_error"])
            items = st.session_state.get("meet_items") or []
            if not items and not st.session_state.get("meet_error"):
                st.markdown('<div class="empty">No meeting requests waiting.</div>', unsafe_allow_html=True)
            for it in items:
                eid = it["email_id"]
                st.markdown(f'<div class="item-head">{esc(it["subject"] or "(no subject)")}</div>'
                            f'<div class="item-meta">From: {esc(it["sender"])} &middot; intent: {esc(it["intent"])} &middot; {it["duration"]} min</div>',
                            unsafe_allow_html=True)
                if it["requested"]:
                    kind = "approximate" if it["approx"] else "exact"
                    st.markdown(f'<div class="item-meta">Requested time: {it["requested"]:%a %d %b, %I:%M %p} ({kind})</div>', unsafe_allow_html=True)
                st.write(it["message"])
                if it["effort"]:
                    line = " | ".join(f'{r["label"].split(" (")[0]} {r["expanded"]} states' for r in it["effort"])
                    st.markdown(f'<div class="effort">Search effort (states expanded): {esc(line)}</div>', unsafe_allow_html=True)
                if it["options"]:
                    labels = [f"{a:%a %d %b, %I:%M %p} - {b:%I:%M %p}   [{how}]" for a, b, how in it["options"]]
                    choice = st.radio("Choose a time", labels, key=f"opt{eid}")
                    b1, b2 = st.columns(2)
                    if b1.button("Book this time", key=f"book{eid}", type="primary"):
                        try:
                            pipeline.book_meeting(uid(), it, labels.index(choice))
                        except Exception as exc:
                            st.error(f"Could not book: {exc}")
                        else:
                            flash("Meeting added to your Google Calendar.")
                            load_meeting_items()
                            st.rerun()
                    if b2.button("No meeting needed", key=f"nomeet{eid}"):
                        pipeline.note_meeting(uid(), eid, "no meeting needed")
                        load_meeting_items()
                        st.rerun()
                elif st.button("Mark as noted", key=f"note{eid}"):
                    pipeline.note_meeting(uid(), eid, it["intent"])
                    load_meeting_items()
                    st.rerun()
                st.divider()
    df = q("SELECT title, start_time, end_time, participants, algorithm_used FROM Meetings WHERE user_id = :u ORDER BY start_time", {"u": uid()})
    df.columns = ["Title", "Start", "End", "Requested by", "How the slot was found"]
    st.markdown('<div class="card-title" style="margin:14px 0 6px">Scheduled meetings</div>', unsafe_allow_html=True)
    st.markdown(html_table(df), unsafe_allow_html=True)


def reminders_page():
    page_head("Reminders")
    show_flash()
    sugg = pipeline.reminder_suggestions(uid())
    if sugg:
        with card("rem_suggest"):
            card_title("Deadlines found in your emails", "Create a reminder with one click. The repeat interval is set by fuzzy logic.")
            for s in sugg:
                note_ = " (approximate time)" if s["approx"] else ""
                st.markdown(f'<div class="item-head">{esc(s["title"])}</div>'
                            f'<div class="item-meta">Deadline {s["deadline"]:%a %d %b, %I:%M %p}{note_} &middot; '
                            f'priority {pill(s["label"])} &middot; reminders every {s["interval"]} min (shortens as the deadline gets closer)</div>',
                            unsafe_allow_html=True)
                c1, c2 = st.columns(2)
                if c1.button("Create reminder", key=f"mk{s['email_id']}", type="primary"):
                    pipeline.create_reminder_from_email(uid(), s)
                    flash("Reminder created.")
                    st.rerun()
                if c2.button("Dismiss", key=f"dm{s['email_id']}"):
                    pipeline.decline_reminder_suggestion(uid(), s["email_id"])
                    st.rerun()
    with st.form("add_reminder", clear_on_submit=True):
        st.markdown('<div class="card-title">Add a reminder</div>', unsafe_allow_html=True)
        task = st.text_input("Task", placeholder="Submit AI Lab assignment")
        f1, f2, f3 = st.columns(3)
        d = f1.date_input("Deadline date")
        t = f2.time_input("Deadline time")
        freq = f3.number_input("Repeat every (minutes)", min_value=5, max_value=1440, value=60)
        if st.form_submit_button("Add reminder"):
            if task.strip():
                add_reminder(task.strip(), datetime.combine(d, t), frequency_minutes=int(freq), user_id=uid())
                flash("Reminder added.")
                st.rerun()
            else:
                st.error("Please enter a task.")
    rows = list_reminders(user_id=uid())
    if not rows:
        st.markdown('<div class="empty">No active reminders.</div>', unsafe_allow_html=True)
    for r in rows:
        with card(f"rem_{r.reminder_id}"):
            c1, c2 = st.columns([4, 1])
            c1.markdown(f'<div class="rem-text"><b>{esc(r.task)}</b><br>'
                        f'<span class="item-meta">Due {r.deadline:%a %d %b, %I:%M %p} &middot; '
                        f'repeats every {int(r.frequency_minutes)} min</span></div>', unsafe_allow_html=True)
            if c2.button("Done", key=f"d{r.reminder_id}"):
                mark_done(r.reminder_id, user_id=uid())
                flash("Reminder marked as done.")
                st.rerun()


def activity_page():
    page_head("Activity log")
    df = q("SELECT TOP 100 logged_at, action, details FROM ActivityLog WHERE user_id = :u ORDER BY log_id DESC", {"u": uid()})
    df.columns = ["Time", "Action", "Details"]
    st.markdown(html_table(df), unsafe_allow_html=True)


def settings_page():
    page_head("Settings")
    show_flash()
    result = st.session_state.pop("oauth_result", None)
    if result:
        (st.success if result[0] == "ok" else st.error)(result[1])
    status = connection_status(uid())
    with card("gmail"):
        card_title("Gmail and Google Calendar", "AutoAssist reads your inbox, sends replies you approve and adds meetings to your calendar.")
        if status:
            when = f"{status['updated_at']:%d %b %Y, %I:%M %p}" if status["updated_at"] else ""
            st.markdown(f'<div class="conn"><span class="dot" style="background:{GREEN}"></span>'
                        f'<b>Connected</b> as {esc(status["address"] or "your Google account")} <span class="note">(updated {when})</span></div>',
                        unsafe_allow_html=True)
        else:
            st.markdown(f'<div class="conn"><span class="dot" style="background:{GREY}"></span><b>Not connected</b></div>', unsafe_allow_html=True)
        consent = st.checkbox("I understand that the text of my emails is sent to an AI service to write reply drafts, "
                              "and that nothing is sent from my account without my approval.", key="consent")
        if consent:
            made = st.session_state.get("oauth_url_at")
            if "oauth_url" not in st.session_state or not made or datetime.now() - made > timedelta(minutes=8):
                try:
                    st.session_state["oauth_url"] = start_oauth(uid())
                    st.session_state["oauth_url_at"] = datetime.now()
                    run("INSERT INTO ActivityLog (user_id, action, details) VALUES (:u, 'consent_given', 'gmail connect')", {"u": uid()})
                except GoogleAuthError as exc:
                    st.error(str(exc))
            if "oauth_url" in st.session_state:
                st.link_button("Reconnect Google account" if status else "Connect Google account", st.session_state["oauth_url"])
        st.markdown('<div class="note">Project testing mode: your Gmail address must be added as a test user by the project owner, '
                    'and the connection expires after 7 days, so you may need to reconnect weekly. '
                    'Connect from the computer that runs AutoAssist.</div>', unsafe_allow_html=True)
        if status and st.button("Disconnect Gmail", key="disc"):
            disconnect(uid())
            flash("Gmail disconnected. Your stored access token was deleted.")
            st.rerun()
    with st.form("name_form"):
        st.markdown('<div class="card-title">Name used in your replies</div>'
                    '<div class="form-sub">Every reply draft is signed with this name.</div>', unsafe_allow_html=True)
        new_name = st.text_input("Your full name", value=st.session_state["user"])
        if st.form_submit_button("Save name"):
            try:
                st.session_state["user"] = update_name(uid(), new_name)
                flash("Name saved. New replies will be signed with it.")
                st.rerun()
            except AccountError as exc:
                st.error(str(exc))
    with st.form("pw_form", clear_on_submit=True):
        st.markdown('<div class="card-title">Change password</div>', unsafe_allow_html=True)
        old = st.text_input("Current password", type="password")
        new1 = st.text_input("New password (at least 8 characters)", type="password")
        new2 = st.text_input("Confirm new password", type="password")
        if st.form_submit_button("Update password"):
            if new1 != new2:
                st.error("The two new passwords do not match.")
            else:
                try:
                    change_password(uid(), old, new1)
                    st.success("Password updated.")
                except AccountError as exc:
                    st.error(str(exc))
    with card("privacy"):
        card_title("Your data", "Delete the emails, drafts, meetings, reminders and the Google token stored for your account.")
        sure = st.checkbox("Yes, delete all my stored mailbox data", key="sure_delete")
        if st.button("Delete my data", key="del_data", disabled=not sure):
            pipeline.delete_user_data(uid())
            st.session_state.pop("meet_items", None)
            flash("All your stored mailbox data was deleted. Your login account still exists.")
            st.rerun()


# ------------------------------------------------------------------ app shell
st.markdown(CSS_COMMON, unsafe_allow_html=True)
handle_google_callback()

if "user_id" not in st.session_state:
    login_page()
    st.stop()

st.markdown(CSS_APP, unsafe_allow_html=True)
st.markdown(CSS_EXTRA, unsafe_allow_html=True)

NAV = [("Dashboard", "▦", dashboard_page), ("Emails", "✉", emails_page),
       ("Pending drafts", "✎", drafts_page), ("Meetings", "◷", meetings_page),
       ("Reminders", "⏰", reminders_page), ("Activity log", "☰", activity_page),
       ("Settings", "⚙", settings_page)]
st.session_state.setdefault("page", "Dashboard")

with st.sidebar:
    st.markdown(f'<div class="side-logo"><div class="badge">{BOLT}</div><div class="name">AutoAssist</div></div>',
                unsafe_allow_html=True)
    for name, icon, _ in NAV:
        active = st.session_state["page"] == name
        if st.button(f"{icon}  {name}", key=f"nav_{name}", type="primary" if active else "secondary"):
            st.session_state["page"] = name
            st.rerun()
    user = st.session_state["user"]
    st.markdown(f'<div class="side-user"><div class="av">{esc(user[:1].upper())}</div>'
                f'<div><div class="nm">{esc(user)}</div><div class="rl">{esc(st.session_state["user_email"])}</div></div></div>',
                unsafe_allow_html=True)
    if st.button("Sign out", key="signout", icon=":material/logout:"):
        sign_out()

for name, _, fn in NAV:
    if name == st.session_state["page"]:
        fn()
