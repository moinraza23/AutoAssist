"""Moves your existing Gmail connection (credentials/token.json) into the database, encrypted, for the FIRST account.
Run once, after migrate_to_multiuser.sql and after adding TOKEN_KEY to .env."""
import os

from google.auth.transport.requests import Request
from google.oauth2.credentials import Credentials
from googleapiclient.discovery import build
from sqlalchemy import text

from app.accounts import default_user_id, get_user
from app.db import engine
from app.google_auth import SCOPES, connection_status, save_token
from app.security import SecurityError, encrypt

try:
    encrypt("test")
except SecurityError as exc:
    raise SystemExit(f"Stop: {exc}")

owner = get_user(default_user_id())
print(f"Existing data belongs to: {owner['name']} <{owner['email']}> (user_id {owner['user_id']})")

with engine.connect() as conn:
    for table in ("Emails", "Drafts", "Meetings", "Reminders", "ActivityLog"):
        n = conn.execute(text(f"SELECT COUNT(*) FROM {table} WHERE user_id IS NULL")).first()[0]
        print(f"  {table}: {n} rows without an owner" + ("  <-- run the .sql script first" if n else ""))

if connection_status(owner["user_id"]):
    print("Gmail is already connected for this account. Nothing to move.")
    raise SystemExit

path = os.path.join("credentials", "token.json")
if not os.path.exists(path):
    print("No credentials/token.json found. Connect Gmail from the dashboard (Settings) instead.")
    raise SystemExit
creds = Credentials.from_authorized_user_file(path, SCOPES)
if not creds.valid and creds.refresh_token:
    creds.refresh(Request())
address = build("gmail", "v1", credentials=creds, cache_discovery=False).users().getProfile(userId="me").execute()["emailAddress"]
save_token(owner["user_id"], creds, address)
print(f"Done. {address} is now connected for {owner['name']} (token stored encrypted in the database).")
print("You can delete credentials/token.json now.")
