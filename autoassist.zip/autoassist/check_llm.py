"""Quick test of your AI settings.
python check_llm.py              -> sends a short test message
python check_llm.py models       -> lists Gemini models with 'flash' in the name
python check_llm.py models all   -> lists every model
"""
import os
import sys

from dotenv import load_dotenv

from app.llm import LLMError, generate

load_dotenv()
provider = os.getenv("LLM_PROVIDER", "gemini")

if len(sys.argv) > 1 and sys.argv[1] == "models":
    from google import genai
    client = genai.Client(api_key=os.getenv("GEMINI_API_KEY"))  # variable zinda rehna chahiye
    show_all = len(sys.argv) > 2 and sys.argv[2] == "all"
    for m in client.models.list():
        name = m.name.replace("models/", "")
        if show_all or "flash" in name.lower():
            print(name)
    raise SystemExit

print(f"Provider: {provider}")
try:
    print(generate("You are a helpful assistant.", "Reply with one short friendly sentence.", 200))
except LLMError as exc:
    print("FAILED:", exc)