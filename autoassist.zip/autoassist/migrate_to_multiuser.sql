-- AutoAssist: multi-user upgrade. Run this ONCE in SSMS (New Query). It is safe to run twice.
-- BEFORE running: make a backup (SSMS: right-click AutoAssistDB > Tasks > Back Up...).
USE AutoAssistDB;
GO

-- 1) Login protection (lock-out after repeated wrong passwords)
IF COL_LENGTH('dbo.Users', 'failed_attempts') IS NULL
    ALTER TABLE dbo.Users ADD failed_attempts INT NOT NULL CONSTRAINT DF_Users_failed_attempts DEFAULT 0;
IF COL_LENGTH('dbo.Users', 'locked_until') IS NULL
    ALTER TABLE dbo.Users ADD locked_until DATETIME2 NULL;
GO

-- 2) Per-user Gmail connection (token is stored ENCRYPTED) and the one-time OAuth state
IF OBJECT_ID('dbo.UserTokens', 'U') IS NULL
    CREATE TABLE dbo.UserTokens (
        user_id       INT           NOT NULL PRIMARY KEY REFERENCES dbo.Users(user_id),
        gmail_address NVARCHAR(255) NULL,
        token_enc     NVARCHAR(MAX) NOT NULL,
        updated_at    DATETIME2     NOT NULL DEFAULT SYSDATETIME()
    );
IF OBJECT_ID('dbo.OAuthStates', 'U') IS NULL
    CREATE TABLE dbo.OAuthStates (
        state         NVARCHAR(200) NOT NULL PRIMARY KEY,
        user_id       INT           NOT NULL,
        code_verifier NVARCHAR(200) NOT NULL,
        created_at    DATETIME2     NOT NULL DEFAULT SYSDATETIME()
    );
GO

-- 3) Every data table now belongs to a user
IF COL_LENGTH('dbo.Emails',      'user_id') IS NULL ALTER TABLE dbo.Emails      ADD user_id INT NULL;
IF COL_LENGTH('dbo.Drafts',      'user_id') IS NULL ALTER TABLE dbo.Drafts      ADD user_id INT NULL;
IF COL_LENGTH('dbo.Meetings',    'user_id') IS NULL ALTER TABLE dbo.Meetings    ADD user_id INT NULL;
IF COL_LENGTH('dbo.Reminders',   'user_id') IS NULL ALTER TABLE dbo.Reminders   ADD user_id INT NULL;
IF COL_LENGTH('dbo.ActivityLog', 'user_id') IS NULL ALTER TABLE dbo.ActivityLog ADD user_id INT NULL;
GO

-- 4) All data that exists today belongs to the FIRST account (the lowest user_id)
DECLARE @owner INT = (SELECT TOP 1 user_id FROM dbo.Users ORDER BY user_id);
IF @owner IS NULL
    PRINT 'No user account exists yet. Create one (python create_user.py) and run this script again.';
ELSE
BEGIN
    UPDATE dbo.Emails      SET user_id = @owner WHERE user_id IS NULL;
    UPDATE dbo.Drafts      SET user_id = @owner WHERE user_id IS NULL;
    UPDATE dbo.Meetings    SET user_id = @owner WHERE user_id IS NULL;
    UPDATE dbo.Reminders   SET user_id = @owner WHERE user_id IS NULL;
    UPDATE dbo.ActivityLog SET user_id = @owner WHERE user_id IS NULL;
    PRINT 'Existing data now belongs to user_id ' + CAST(@owner AS VARCHAR(10));
END
GO

-- 5) Indexes so each user's pages stay fast
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'IX_Emails_user' AND object_id = OBJECT_ID('dbo.Emails'))
    CREATE INDEX IX_Emails_user ON dbo.Emails(user_id);
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'IX_Drafts_user' AND object_id = OBJECT_ID('dbo.Drafts'))
    CREATE INDEX IX_Drafts_user ON dbo.Drafts(user_id);
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'IX_Reminders_user' AND object_id = OBJECT_ID('dbo.Reminders'))
    CREATE INDEX IX_Reminders_user ON dbo.Reminders(user_id);
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'IX_ActivityLog_user' AND object_id = OBJECT_ID('dbo.ActivityLog'))
    CREATE INDEX IX_ActivityLog_user ON dbo.ActivityLog(user_id);
GO

-- 6) Check: every number in the second column should be 0
SELECT 'Emails' AS tbl, COUNT(*) AS rows_without_owner FROM dbo.Emails WHERE user_id IS NULL
UNION ALL SELECT 'Drafts', COUNT(*) FROM dbo.Drafts WHERE user_id IS NULL
UNION ALL SELECT 'Meetings', COUNT(*) FROM dbo.Meetings WHERE user_id IS NULL
UNION ALL SELECT 'Reminders', COUNT(*) FROM dbo.Reminders WHERE user_id IS NULL
UNION ALL SELECT 'ActivityLog', COUNT(*) FROM dbo.ActivityLog WHERE user_id IS NULL;
GO
