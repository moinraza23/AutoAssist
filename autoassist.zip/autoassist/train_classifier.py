"""Trains and compares two classifiers, saves the best one to models/email_classifier.joblib."""
import json
import os

import joblib
import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix, f1_score
from sklearn.model_selection import GroupKFold, GroupShuffleSplit, cross_val_score
from sklearn.naive_bayes import MultinomialNB
from sklearn.pipeline import Pipeline

from app.classifier import MODEL_PATH, build_text

df = pd.read_csv("data/emails_labeled.csv").fillna("")
if os.path.exists("data/my_labeled.csv"):  # optional: your own corrected real emails
    mine = pd.read_csv("data/my_labeled.csv").fillna("")
    mine["group"] = [f"mine_{i}" for i in range(len(mine))]
    df = pd.concat([df, mine], ignore_index=True)

X = [build_text(r.sender, r.subject, r.body) for r in df.itertuples()]
y = df["category"].tolist()
groups = df["group"].tolist()
print(f"Training samples: {len(df)}")
print(df["category"].value_counts().to_string(), "\n")


def tfidf():
    return TfidfVectorizer(ngram_range=(1, 2), sublinear_tf=True, lowercase=True)


models = {
    "Naive Bayes": Pipeline([("tfidf", tfidf()), ("clf", MultinomialNB(alpha=0.3))]),
    "Logistic Regression": Pipeline([("tfidf", tfidf()), ("clf", LogisticRegression(max_iter=2000, C=10))]),
}

# Honest evaluation: the same sentence template never appears in both train and test,
# so the score shows how well the model handles phrasings it has NOT seen before.
tr_idx, te_idx = next(GroupShuffleSplit(n_splits=1, test_size=0.25, random_state=42).split(X, y, groups))
X_tr, X_te = [X[i] for i in tr_idx], [X[i] for i in te_idx]
y_tr, y_te = [y[i] for i in tr_idx], [y[i] for i in te_idx]
cv = GroupKFold(n_splits=5)
labels = sorted(set(y))
results, best_name, best_cv = {}, None, -1

for name, pipe in models.items():
    cv_acc = float(cross_val_score(pipe, X, y, groups=groups, cv=cv, scoring="accuracy").mean())
    pipe.fit(X_tr, y_tr)
    pred = pipe.predict(X_te)
    results[name] = {"cv_accuracy": round(cv_acc, 4),
                     "test_accuracy": round(float(accuracy_score(y_te, pred)), 4),
                     "test_macro_f1": round(float(f1_score(y_te, pred, average="macro")), 4)}
    print(f"=== {name} ===")
    print(f"5-fold CV accuracy (unseen phrasing): {cv_acc:.3f} | hold-out accuracy: {results[name]['test_accuracy']:.3f}")
    print(classification_report(y_te, pred, digits=3))
    print("Confusion matrix (rows = true, cols = predicted):", labels)
    print(confusion_matrix(y_te, pred, labels=labels), "\n")
    if cv_acc > best_cv:
        best_name, best_cv = name, cv_acc

best = models[best_name]
cm = confusion_matrix(y_te, best.predict(X_te), labels=labels).tolist()
best.fit(X, y)  # final model learns from all data
os.makedirs(os.path.dirname(MODEL_PATH), exist_ok=True)
joblib.dump(best, MODEL_PATH)
with open(os.path.join(os.path.dirname(MODEL_PATH), "metrics.json"), "w") as f:
    json.dump({"best_model": best_name, "n_samples": len(df), "labels": labels,
               "models": results, "confusion_matrix": cm}, f, indent=2)
print(f"Best model: {best_name}. Saved to models/email_classifier.joblib")
