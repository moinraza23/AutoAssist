import time
from datetime import datetime

import schedule
from sqlalchemy import text

from app.db import engine
from app.fuzzy import reminder_interval
from app.reminders import due_reminders, mark_notified

try:
    from plyer import notification
except Exception:
    notification = None


def notify(title, message):
    print(f"\n*** REMINDER: {message}")
    if notification:
        try:
            notification.notify(title=title, message=message, timeout=10)
        except Exception:
            pass  # console message to mil hi gaya


def refresh_frequencies():
    """Fuzzy logic: the closer the deadline (and the higher the priority), the more often we remind."""
    now = datetime.now()
    with engine.begin() as conn:
        rows = conn.execute(text(
            "SELECT reminder_id, deadline, priority FROM Reminders WHERE status = 'active'")).fetchall()
        for r in rows:
            hours_left = (r.deadline - now).total_seconds() / 3600
            conn.execute(text("UPDATE Reminders SET frequency_minutes=:f WHERE reminder_id=:i"),
                         {"f": reminder_interval(hours_left, r.priority), "i": r.reminder_id})


def check():
    refresh_frequencies()
    for r in due_reminders(window_hours=48):          # all users: this is the desktop notifier of the host computer
        notify("AutoAssist Reminder", f"{r.task} (due {r.deadline:%a %d %b, %I:%M %p})")
        mark_notified(r.reminder_id)
        with engine.begin() as conn:
            conn.execute(text("INSERT INTO ActivityLog (user_id, action, details) VALUES (:u, :a, :d)"),
                         {"u": r.user_id, "a": "reminder_notified", "d": r.task})


check()
schedule.every(30).seconds.do(check)
print("Reminder checker running (fuzzy adaptive intervals)... stop karne ke liye Ctrl + C")
while True:
    schedule.run_pending()
    time.sleep(1)
