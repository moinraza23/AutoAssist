"""One-click database upgrade for the multi-user version of AutoAssist.

It connects with the SAME settings as the dashboard (DB_URL in .env), so it always upgrades the database
that the dashboard really uses. It shows what is missing, fixes it, and checks again.

    python run_migration.py            -> check, upgrade, check again
    python run_migration.py --check    -> only check (changes nothing)
"""
import re
import sys

from sqlalchemy import inspect, text

from app.db import engine

NEEDED = {
    "Users": ["user_id", "name", "email", "password_hash", "role", "failed_attempts", "locked_until"],
    "UserTokens": ["user_id", "gmail_address", "token_enc", "updated_at"],
    "OAuthStates": ["state", "user_id", "code_verifier", "created_at"],
    "Emails": ["email_id", "user_id", "gmail_id", "thread_id", "sender", "subject", "body", "received_at",
               "category", "confidence", "classified_by", "priority_score", "status"],
    "Drafts": ["draft_id", "user_id", "email_id", "reply_text", "status", "created_at", "sent_at", "generated_by"],
    "Meetings": ["meeting_id", "user_id", "email_id", "title", "start_time", "end_time", "participants", "algorithm_used"],
    "Reminders": ["reminder_id", "user_id", "task", "deadline", "priority", "frequency_minutes", "status", "last_notified"],
    "ActivityLog": ["log_id", "user_id", "logged_at", "action", "details"],
    "AlgorithmRuns": ["run_id", "algorithm", "states_expanded", "time_ms", "result_quality", "run_at"],
}

MIGRATION_SQL = r"""
-- AutoAssist: multi-user upgrade. Run this ONCE in SSMS (New Query). It is safe to run twice.
-- BEFORE running: make a backup (SSMS: right-click AutoAssistDB > Tasks > Back Up...).
-- 1) Login protection (lock-out after repeated wrong passwords)
IF COL_LENGTH('dbo.Users', 'failed_attempts') IS NULL
    ALTER TABLE dbo.Users ADD failed_attempts INT NOT NULL CONSTRAINT DF_Users_failed_attempts DEFAULT 0;
IF COL_LENGTH('dbo.Users', 'locked_until') IS NULL
    ALTER TABLE dbo.Users ADD locked_until DATETIME2 NULL;
GO

-- 2) Per-user Gmail connection (token is stored ENCRYPTED) and the one-time OAuth state
IF OBJECT_ID('dbo.UserTokens', 'U') IS NULL
    CREATE TABLE dbo.UserTokens (
        user_id       INT           NOT NULL PRIMARY KEY REFERENCES dbo.Users(user_id),
        gmail_address NVARCHAR(255) NULL,
        token_enc     NVARCHAR(MAX) NOT NULL,
        updated_at    DATETIME2     NOT NULL DEFAULT SYSDATETIME()
    );
IF OBJECT_ID('dbo.OAuthStates', 'U') IS NULL
    CREATE TABLE dbo.OAuthStates (
        state         NVARCHAR(200) NOT NULL PRIMARY KEY,
        user_id       INT           NOT NULL,
        code_verifier NVARCHAR(200) NOT NULL,
        created_at    DATETIME2     NOT NULL DEFAULT SYSDATETIME()
    );
GO

-- 3) Every data table now belongs to a user
IF COL_LENGTH('dbo.Emails',      'user_id') IS NULL ALTER TABLE dbo.Emails      ADD user_id INT NULL;
IF COL_LENGTH('dbo.Drafts',      'user_id') IS NULL ALTER TABLE dbo.Drafts      ADD user_id INT NULL;
IF COL_LENGTH('dbo.Meetings',    'user_id') IS NULL ALTER TABLE dbo.Meetings    ADD user_id INT NULL;
IF COL_LENGTH('dbo.Reminders',   'user_id') IS NULL ALTER TABLE dbo.Reminders   ADD user_id INT NULL;
IF COL_LENGTH('dbo.ActivityLog', 'user_id') IS NULL ALTER TABLE dbo.ActivityLog ADD user_id INT NULL;
GO

-- 4) All data that exists today belongs to the FIRST account (the lowest user_id)
DECLARE @owner INT = (SELECT TOP 1 user_id FROM dbo.Users ORDER BY user_id);
IF @owner IS NULL
    PRINT 'No user account exists yet. Create one (python create_user.py) and run this script again.';
ELSE
BEGIN
    UPDATE dbo.Emails      SET user_id = @owner WHERE user_id IS NULL;
    UPDATE dbo.Drafts      SET user_id = @owner WHERE user_id IS NULL;
    UPDATE dbo.Meetings    SET user_id = @owner WHERE user_id IS NULL;
    UPDATE dbo.Reminders   SET user_id = @owner WHERE user_id IS NULL;
    UPDATE dbo.ActivityLog SET user_id = @owner WHERE user_id IS NULL;
    PRINT 'Existing data now belongs to user_id ' + CAST(@owner AS VARCHAR(10));
END
GO

-- 5) Indexes so each user's pages stay fast
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'IX_Emails_user' AND object_id = OBJECT_ID('dbo.Emails'))
    CREATE INDEX IX_Emails_user ON dbo.Emails(user_id);
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'IX_Drafts_user' AND object_id = OBJECT_ID('dbo.Drafts'))
    CREATE INDEX IX_Drafts_user ON dbo.Drafts(user_id);
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'IX_Reminders_user' AND object_id = OBJECT_ID('dbo.Reminders'))
    CREATE INDEX IX_Reminders_user ON dbo.Reminders(user_id);
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'IX_ActivityLog_user' AND object_id = OBJECT_ID('dbo.ActivityLog'))
    CREATE INDEX IX_ActivityLog_user ON dbo.ActivityLog(user_id);
GO

-- 6) Check: every number in the second column should be 0
SELECT 'Emails' AS tbl, COUNT(*) AS rows_without_owner FROM dbo.Emails WHERE user_id IS NULL
UNION ALL SELECT 'Drafts', COUNT(*) FROM dbo.Drafts WHERE user_id IS NULL
UNION ALL SELECT 'Meetings', COUNT(*) FROM dbo.Meetings WHERE user_id IS NULL
UNION ALL SELECT 'Reminders', COUNT(*) FROM dbo.Reminders WHERE user_id IS NULL
UNION ALL SELECT 'ActivityLog', COUNT(*) FROM dbo.ActivityLog WHERE user_id IS NULL;
GO
"""


def split_batches(sql):
    """SSMS understands the word GO as 'end of batch'. Python does not, so we cut the script at every GO line."""
    sql = sql.replace("dbo.", "")          # use the default schema, exactly like the dashboard does
    return [b.strip() for b in re.split(r"^\s*GO\s*$", sql, flags=re.IGNORECASE | re.MULTILINE) if b.strip()]


def where_am_i():
    try:
        with engine.connect() as conn:
            server, database = conn.execute(text("SELECT @@SERVERNAME, DB_NAME()")).first()
        print(f"Connected to server '{server}', database '{database}'  (this is the database the dashboard uses)")
    except Exception:
        print("Connected (server name not available)")


def check():
    """Returns {table: [missing columns]} (a missing table lists all its columns)."""
    insp = inspect(engine)
    tables = {t.lower(): t for t in insp.get_table_names()}
    missing = {}
    for table, cols in NEEDED.items():
        real = tables.get(table.lower())
        have = {c["name"].lower() for c in insp.get_columns(real)} if real else set()
        gap = [c for c in cols if c.lower() not in have]
        if gap:
            missing[table] = gap if real else ["(whole table is missing)"]
    return missing


def show(missing):
    if not missing:
        print("  Everything is in place.")
    for table, cols in missing.items():
        print(f"  MISSING in {table}: {', '.join(cols)}")


def migrate():
    batches = split_batches(MIGRATION_SQL)
    failures = 0
    conn = engine.connect().execution_options(isolation_level="AUTOCOMMIT")
    for i, batch in enumerate(batches, 1):
        try:
            result = conn.exec_driver_sql(batch)
            if result.returns_rows:
                for row in result.fetchall():
                    print("     ", tuple(row))
            print(f"  step {i}/{len(batches)}: ok")
        except Exception as exc:
            failures += 1
            print(f"  step {i}/{len(batches)}: FAILED -> {str(exc).splitlines()[0][:300]}")
    conn.close()
    return failures


if __name__ == "__main__":
    where_am_i()
    print("\nBEFORE:")
    before = check()
    show(before)
    if "--check" in sys.argv:
        raise SystemExit(0)
    if before:
        print("\nUpgrading the database...")
        failed = migrate()
        print("\nAFTER:")
        after = check()
        show(after)
        if after or failed:
            print("\nSomething is still missing. Copy this whole output and send it to Claude.")
            raise SystemExit(1)
    print("\nDONE. The database is ready for the multi-user dashboard.")
