"""Re-labels the emails already in the database with the ML model and shows what changed."""
from sqlalchemy import text

from app.classifier import classify
from app.db import engine

with engine.connect() as conn:
    rows = conn.execute(text(
        "SELECT email_id, sender, subject, body, category, status FROM Emails")).fetchall()

changes = []
with engine.begin() as conn:
    for r in rows:
        cat, conf, method = classify(r.sender, r.subject, r.body)
        if cat != r.category:
            changes.append((r.subject or "(no subject)", r.category, cat, conf))
        # emails that were skipped as spam but are not spam any more get a draft later
        new_status = "new" if (r.status == "ignored" and cat != "spam") else r.status
        conn.execute(text("""UPDATE Emails SET category=:c, confidence=:f, classified_by=:m, status=:s
                             WHERE email_id=:i"""),
                     {"c": cat, "f": conf, "m": method, "s": new_status, "i": r.email_id})
    conn.execute(text("INSERT INTO ActivityLog (action, details) VALUES (:a, :d)"),
                 {"a": "reclassify", "d": f"{len(rows)} emails checked, {len(changes)} changed"})

print(f"{len(rows)} emails checked, {len(changes)} got a different category than the keyword rules.\n")
for subject, old, new, conf in changes[:20]:
    shown = f"{conf:.2f}" if conf is not None else "-"
    print(f"{subject[:50]:50} | rules: {old:8} -> ML: {new:8} (confidence {shown})")
