"""Scores every email in the database with the fuzzy priority system and prints a ranking."""
from datetime import datetime

from sqlalchemy import text

from app.db import engine
from app.priority import email_priority

now = datetime.now()
with engine.connect() as conn:
    rows = conn.execute(text(
        "SELECT email_id, sender, subject, body, category, received_at FROM Emails")).fetchall()

results = []
with engine.begin() as conn:
    for r in rows:
        p = email_priority(r.sender, r.subject, r.body, r.category, r.received_at, now)
        conn.execute(text("UPDATE Emails SET priority_score=:s WHERE email_id=:i"),
                     {"s": p["score"], "i": r.email_id})
        results.append((p["score"], p["label"], r.category, r.subject or "(no subject)", p))
    conn.execute(text("INSERT INTO ActivityLog (action, details) VALUES ('score_priorities', :d)"),
                 {"d": f"{len(rows)} emails scored"})

results.sort(key=lambda x: x[0], reverse=True)
print(f"{len(rows)} emails scored.\n")
print(f"{'Score':>6}  {'Level':8} {'Category':9} Subject")
for score, label, cat, subject, _ in results[:15]:
    print(f"{score:6.1f}  {label:8} {cat:9} {subject[:55]}")

if results and results[0][4]["fired"]:
    top = results[0]
    print(f"\nWhy is '{top[3][:40]}' ranked first?")
    print("Inputs:", top[4]["inputs"])
    for strength, rule in top[4]["fired"][:5]:
        print(f"  {strength:.2f}  IF {rule}")
