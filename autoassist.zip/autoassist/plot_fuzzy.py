"""Draws the membership functions of both fuzzy systems into reports/fuzzy_membership.png (for the report)."""
import os

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

from app.fuzzy import priority_system, reminder_system

RANGES = {"deadline_hours": (0, 168), "importance": (0, 10), "waiting_hours": (0, 72),
          "hours_left": (0, 168), "priority": (0, 100)}
panels = [("Priority system", name, priority_system.inputs[name]) for name in priority_system.inputs]
panels.append(("Priority system", "priority (output)", priority_system.output))
panels += [("Reminder system", name, reminder_system.inputs[name]) for name in ("hours_left",)]
panels.append(("Reminder system", "interval minutes (output)", reminder_system.output))

fig, axes = plt.subplots(2, 4, figsize=(18, 7))
for ax, (system, name, sets) in zip(axes.flat, panels):
    key = name.split(" ")[0]
    lo, hi = RANGES.get(key, (0, 100))
    if "interval" in name:
        lo, hi = 10, 240
    xs = [lo + (hi - lo) * i / 300 for i in range(301)]
    for label, mu in sets.items():
        ax.plot(xs, [mu(x) for x in xs], label=label.replace("_", " "), linewidth=2)
    ax.set_title(f"{system}: {name.replace('_', ' ')}", fontsize=10)
    ax.set_ylim(-0.05, 1.1)
    ax.legend(fontsize=8)
    ax.grid(alpha=0.3)
for ax in list(axes.flat)[len(panels):]:
    ax.axis("off")
plt.tight_layout()
os.makedirs("reports", exist_ok=True)
plt.savefig("reports/fuzzy_membership.png", dpi=150)
print("Saved reports/fuzzy_membership.png")
