"""Batch job: reads the inbox of EVERY user who connected Gmail. (Users can also press 'Sync' in the dashboard.)"""
from sqlalchemy import text

from app.db import engine
from app.google_auth import GoogleAuthError
from app.pipeline import sync_inbox

with engine.connect() as conn:
    users = conn.execute(text("""SELECT u.user_id, u.email FROM Users u
                                 JOIN UserTokens t ON t.user_id = u.user_id ORDER BY u.user_id""")).fetchall()
if not users:
    print("No user has connected Gmail yet.")
for u in users:
    try:
        r = sync_inbox(u.user_id)
        print(f"{u.email}: {r['new']} new emails ({r['ml']} classified by ML)")
    except GoogleAuthError as exc:
        print(f"{u.email}: skipped. {exc}")
