"""Checks that every algorithm returns valid slots, and that A* is optimal (same quality as BFS)."""
import random
from datetime import datetime, timedelta

from app.scheduler_rules import check_slot
from app.search import SlotProblem, search

NOW = datetime(2026, 11, 16, 9, 0)


def random_busy(rng, load):
    busy = []
    for d in range(0, 17):
        day = (NOW + timedelta(days=d)).replace(hour=0, minute=0)
        for _ in range(rng.randint(*load)):
            s = day + timedelta(minutes=30 * rng.randint(18, 33))
            busy.append((s, s + timedelta(minutes=rng.choice([30, 60, 90, 120]))))
    return busy


rng = random.Random(7)
checked = 0
for trial in range(150):
    busy = random_busy(rng, rng.choice([(0, 2), (2, 4), (4, 6)]))
    target = (NOW + timedelta(days=rng.randint(0, 9))).replace(hour=rng.randint(0, 23), minute=rng.choice([0, 30]))
    dur = rng.choice([30, 60, 90])
    p = SlotProblem(busy, target, dur, NOW)
    res = {a: search(p, a, k=3) for a in ("bfs", "dfs", "astar", "wastar")}
    for a, r in res.items():
        for s, e in r["slots"]:
            assert check_slot(busy, s, dur, NOW)[0], (a, s)   # every returned slot is really usable
        checked += len(r["slots"])
    assert res["astar"]["shift_min"] == res["bfs"]["shift_min"], (res["astar"], res["bfs"])   # A* is optimal
    assert res["wastar"]["shift_min"] <= 3 * res["bfs"]["shift_min"] + 30 or res["bfs"]["shift_min"] is None
print(f"All {checked} returned slots are valid. A* found the same best slot as BFS in all 150 scenarios. PASS")
