"""Batch job: writes reply drafts for EVERY user who connected Gmail. (Users can also press 'Sync' in the dashboard.)"""
from sqlalchemy import text

from app.db import engine
from app.pipeline import generate_drafts

with engine.connect() as conn:
    users = conn.execute(text("""SELECT u.user_id, u.email FROM Users u
                                 JOIN UserTokens t ON t.user_id = u.user_id ORDER BY u.user_id""")).fetchall()
for u in users:
    r = generate_drafts(u.user_id)
    print(f"{u.email}: {r['made']} drafts ({r['llm']} by AI, {r['templates']} from templates)")
    for note in r["notes"]:
        print("   note:", note)
    if r["left"]:
        print(f"   {r['left']} emails still waiting, run again")
