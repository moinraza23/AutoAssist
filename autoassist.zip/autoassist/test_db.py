import os
from dotenv import load_dotenv
from sqlalchemy import create_engine, text

load_dotenv()
engine = create_engine(os.getenv("DB_URL"))

with engine.connect() as conn:
    rows = conn.execute(text("SELECT name FROM sys.tables ORDER BY name")).fetchall()
    print([r[0] for r in rows])