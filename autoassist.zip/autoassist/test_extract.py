"""Mini test-suite for the extractor. Today is fixed to Monday 16 Nov 2026, 10:00."""
from datetime import datetime

from app.extract import detect_intent, extract_datetime

NOW = datetime(2026, 11, 16, 10, 0)
D = lambda d, h=0, m=0: datetime(2026, 11, d, h, m)

CASES = [
    ("Can we meet tomorrow at 3 PM?", D(17, 15)),
    ("kal 3 baje meeting rakh lein", D(17, 15)),
    ("Let us meet on Wednesday morning", D(18, 10)),
    ("Please submit the report by Friday 5 pm", D(20, 17)),
    ("The deadline is 25th November at 11:30 am", D(25, 11, 30)),
    ("Zoom call next Monday at 2 pm for 30 minutes", D(23, 14)),
    ("free ho to aaj shaam 6 baje call karte hain", D(16, 18)),
    ("Assignment due 2026-11-30", D(30, 10)),
    ("Meeting parson subah 10 baje", D(18, 10)),
    ("How are you doing?", None),
    ("Let us meet next week", D(23, 10)),
    ("Quick meeting at 4 pm", D(16, 16)),
    ("this Friday at 11", D(20, 11)),
    ("The deadline is midnight tonight", D(16, 23, 59)),
    ("Can we talk on Dec 3 at 9:30?", datetime(2026, 12, 3, 9, 30)),
    ("meeting on 20/11 at 2:15 pm", D(20, 14, 15)),
]
ok = 0
for text, want in CASES:
    got = extract_datetime(text, NOW)["start"]
    good = got == want
    ok += good
    print(("PASS" if good else "FAIL"), "|", text, "->", got, "" if good else f"(expected {want})")
print(f"\nDates/times: {ok}/{len(CASES)} correct")

INTENTS = [("Can we schedule a meeting tomorrow?", "request"),
           ("Please cancel tomorrow's meeting", "cancel"),
           ("The meeting is moved to Friday, please confirm", "reschedule"),
           ("Sounds good, see you then", "confirm"),
           ("Can we reschedule to next week?", "reschedule")]
ok2 = 0
for text, want in INTENTS:
    got = detect_intent(text)
    ok2 += got == want
    print(("PASS" if got == want else "FAIL"), "|", text, "->", got)
print(f"Intents: {ok2}/{len(INTENTS)} correct")
print("Duration test:", extract_datetime("call for 45 minutes tomorrow at 3 pm", NOW)["duration_min"], "(expected 45)")
