"""Compares the Genetic Algorithm with a Greedy planner and with Random search (same number of evaluations).
python compare_ga.py            -> table + reports/ga_comparison.csv / .png / ga_convergence.png
python compare_ga.py --save     -> also stores every run in the AlgorithmRuns table (for the dashboard)
"""
import csv
import os
import random
import sys
from datetime import datetime, timedelta

from app.genetic import Item, Problem, metrics, run_ga, run_greedy, run_random

NOW = datetime(2026, 11, 23, 9, 0)          # a fixed Monday, so every run gives the same numbers
N_SCENARIOS = 45
LOADS = {"light": (5, (0, 1)), "medium": (8, (1, 3)), "heavy": (12, (2, 4))}   # (items, busy events per day)


def scenario(rng, load):
    n_items, (lo, hi) = LOADS[load]
    day = lambda d, h, m=0: NOW.replace(hour=h, minute=m) + timedelta(days=d)
    busy = []
    for d in range(5):
        for _ in range(rng.randint(lo, hi)):
            s = day(d, 9) + timedelta(minutes=30 * rng.randint(0, 14))
            busy.append((s, s + timedelta(minutes=rng.choice([30, 60, 90, 120]))))
    items = []
    for i in range(n_items):
        pr = rng.randint(20, 95)
        if rng.random() < 0.6:
            items.append(Item(i, f"Meeting {i}", "meeting", rng.choice([30, 60, 90]), pr,
                              preferred=day(rng.randint(0, 4), rng.randint(9, 16), rng.choice([0, 30]))))
        else:
            items.append(Item(i, f"Task {i}", "task", rng.choice([60, 90, 120]), pr,
                              deadline=day(rng.randint(0, 4), rng.randint(12, 17))))
    return items, busy


rng = random.Random(2026)
rows, shown = [], None
for sc in range(N_SCENARIOS):
    load = ["light", "medium", "heavy"][sc % 3]
    items, busy = scenario(rng, load)
    p = Problem(items, busy, NOW, 5)
    ga = run_ga(p, seed=sc)
    budget = ga["evaluations"]
    results = {"Genetic Algorithm": ga, "Greedy": run_greedy(p), "Random search": run_random(p, budget, seed=sc)}
    if shown is None and load == "heavy":
        shown = ga
    for name, r in results.items():
        m = metrics(p, r["genes"])
        rows.append({"scenario": sc, "load": load, "method": name, "evaluations": r["evaluations"], "time_ms": round(r["time_ms"], 1),
                     "cost": round(m["cost"], 1), "conflicts": m["conflicts"], "missed": m["missed_deadlines"],
                     "unscheduled": m["unscheduled"], "avg_shift": round(m["avg_shift_min"], 1)})

methods = ["Genetic Algorithm", "Greedy", "Random search"]
print(f"{N_SCENARIOS} random weeks (light, medium and heavy: 5 to 12 meetings and tasks, with a busy calendar)\n")
print(f"{'Method':20}{'Avg cost':>10}{'Conflicts':>11}{'Missed dl.':>12}{'Unsched.':>10}{'Avg shift':>11}{'Avg ms':>9}")
summary = []
for mth in methods:
    rs = [r for r in rows if r["method"] == mth]
    avg = lambda k: sum(r[k] for r in rs) / len(rs)
    summary.append((mth, avg("cost"), avg("conflicts"), avg("missed"), avg("unscheduled"), avg("avg_shift"), avg("time_ms")))
    print(f"{mth:20}{avg('cost'):10.0f}{avg('conflicts'):11.2f}{avg('missed'):12.2f}{avg('unscheduled'):10.2f}{avg('avg_shift'):9.0f} m{avg('time_ms'):9.0f}")
ga_rows = {r["scenario"]: r for r in rows if r["method"] == "Genetic Algorithm"}
gr_rows = {r["scenario"]: r for r in rows if r["method"] == "Greedy"}
rn_rows = {r["scenario"]: r for r in rows if r["method"] == "Random search"}
wins_g = sum(ga_rows[s]["cost"] < gr_rows[s]["cost"] - 1e-6 for s in ga_rows)
ties_g = sum(abs(ga_rows[s]["cost"] - gr_rows[s]["cost"]) <= 1e-6 for s in ga_rows)
loss_g = N_SCENARIOS - wins_g - ties_g
wins_r = sum(ga_rows[s]["cost"] < rn_rows[s]["cost"] - 1e-6 for s in ga_rows)
print(f"\nGA beat Greedy in {wins_g} of {N_SCENARIOS} weeks (tied in {ties_g}, lost in {loss_g}); GA beat Random search in {wins_r} of {N_SCENARIOS}.")
for load in LOADS:
    sub = [s for s in ga_rows if ga_rows[s]["load"] == load]
    imp = sum((gr_rows[s]["cost"] - ga_rows[s]["cost"]) / max(gr_rows[s]["cost"], 1) for s in sub) / len(sub) * 100
    print(f"  {load:7}: GA cost is on average {imp:5.1f}% lower than Greedy")
print("Cost = total penalty (lower is better). Avg shift = minutes a meeting is moved from the requested time.")

os.makedirs("reports", exist_ok=True)
with open("reports/ga_comparison.csv", "w", newline="") as f:
    w = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
    w.writeheader()
    w.writerows(rows)
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
colors = ["#0aa5a8", "#f5a31a", "#b8c2cf"]
fig, axes = plt.subplots(1, 3, figsize=(14, 4.2))
for ax, idx, title in zip(axes, (1, 2, 4), ("Average cost (lower is better)", "Average conflicts", "Average unscheduled items")):
    ax.bar([s[0] for s in summary], [s[idx] for s in summary], color=colors)
    ax.set_title(title, fontsize=11)
    ax.tick_params(axis="x", labelsize=8)
    ax.grid(axis="y", alpha=0.3)
plt.tight_layout()
plt.savefig("reports/ga_comparison.png", dpi=150)
plt.figure(figsize=(7, 4))
plt.plot(shown["history"]["best"], color="#0aa5a8", linewidth=2.5, label="best of generation")
plt.plot(shown["history"]["avg"], color="#f5a31a", linewidth=1.8, label="average of population")
plt.yscale("log")
plt.xlabel("Generation")
plt.ylabel("Cost (log scale)")
plt.title("Genetic Algorithm: the schedule improves over generations")
plt.legend()
plt.grid(alpha=0.3)
plt.tight_layout()
plt.savefig("reports/ga_convergence.png", dpi=150)
print("Saved reports/ga_comparison.csv, ga_comparison.png and ga_convergence.png")

if "--save" in sys.argv:
    from sqlalchemy import text
    from app.db import engine
    with engine.begin() as conn:
        for r in rows:
            conn.execute(text("""INSERT INTO AlgorithmRuns (algorithm, states_expanded, time_ms, result_quality)
                                 VALUES (:a, :s, :t, :q)"""),
                         {"a": r["method"] + " (weekly planner)", "s": r["evaluations"], "t": r["time_ms"], "q": r["cost"]})
        conn.execute(text("INSERT INTO ActivityLog (action, details) VALUES ('compare_ga', :d)"), {"d": f"{len(rows)} runs saved"})
    print(f"Saved {len(rows)} runs to the AlgorithmRuns table.")
