"""Creates a login account from the command line (people can also register in the dashboard)."""
import getpass

from app.accounts import AccountError, create_user

name = input("Full name: ").strip()
email = input("Login email: ").strip()
role = input("Role [user/admin] (Enter = user): ").strip().lower() or "user"
pw = getpass.getpass("Password (typing will not be shown): ")
try:
    create_user(name, email, pw, role=role if role in ("user", "admin") else "user", check_code=False)
    print("User created.")
except AccountError as exc:
    print("Could not create the user:", exc)
