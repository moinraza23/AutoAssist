"""Runs BFS, DFS, A* and Weighted A* on the same random scheduling problems and compares them.
python compare_algorithms.py            -> table + reports/algorithm_comparison.csv/.png
python compare_algorithms.py --save     -> also stores every run in the AlgorithmRuns table (for the dashboard)
"""
import csv
import os
import random
import sys
from datetime import datetime, timedelta

from app.search import SlotProblem, search

NOW = datetime(2026, 11, 16, 9, 0)      # fixed "today" so results are reproducible
N_SCENARIOS = 200
ALGOS = [("bfs", 2.0), ("dfs", 2.0), ("astar", 2.0), ("wastar", 2.0), ("wastar", 4.0)]


def random_busy(rng, load):
    busy = []
    for d in range(0, 17):
        day = (NOW + timedelta(days=d)).replace(hour=0, minute=0)
        for _ in range(rng.randint(*load)):
            s = day + timedelta(minutes=30 * rng.randint(18, 33))
            busy.append((s, s + timedelta(minutes=rng.choice([30, 60, 90, 120]))))
    return busy


rng = random.Random(42)
rows = []
for sc in range(N_SCENARIOS):
    load_name, load = rng.choice([("light", (0, 2)), ("medium", (2, 4)), ("heavy", (4, 6))])
    busy = random_busy(rng, load)
    target = (NOW + timedelta(days=rng.randint(0, 9))).replace(hour=rng.randint(0, 23), minute=rng.choice([0, 30]))
    dur = rng.choice([30, 60, 90])
    problem = SlotProblem(busy, target, dur, NOW)
    for algo, w in ALGOS:
        r = search(problem, algo, k=1, w=w)
        rows.append({"scenario": sc, "load": load_name, "algorithm": r["label"], "expanded": r["expanded"],
                     "time_ms": r["time_ms"], "shift_min": r["shift_min"], "found": r["found"]})

labels = list(dict.fromkeys(r["algorithm"] for r in rows))
best = {}
for r in rows:   # best (smallest) shift per scenario = the optimum
    if r["shift_min"] is not None:
        best[r["scenario"]] = min(best.get(r["scenario"], 1e9), r["shift_min"])

print(f"{N_SCENARIOS} random scheduling problems (light, medium and heavy calendars, requests at all hours incl. weekends)\n")
print(f"{'Algorithm':18}{'Avg states':>11}{'Avg ms':>9}{'Avg shift':>11}{'Optimal':>9}{'Solved':>8}")
summary = []
for lab in labels:
    rs = [r for r in rows if r["algorithm"] == lab]
    solved = [r for r in rs if r["found"]]
    avg_states = sum(r["expanded"] for r in rs) / len(rs)
    avg_ms = sum(r["time_ms"] for r in rs) / len(rs)
    avg_shift = sum(r["shift_min"] for r in solved) / max(len(solved), 1)
    optimal = 100 * sum(1 for r in solved if r["shift_min"] == best[r["scenario"]]) / len(rs)
    summary.append((lab, avg_states, avg_ms, avg_shift, optimal, 100 * len(solved) / len(rs)))
    print(f"{lab:18}{avg_states:11.1f}{avg_ms:9.2f}{avg_shift:9.0f} m{optimal:8.0f}%{100 * len(solved) / len(rs):7.0f}%")
print("\nAvg shift = how far (minutes) the chosen slot is from the requested time (smaller is better).")
print("Optimal   = share of problems where the algorithm found the closest possible slot.")

os.makedirs("reports", exist_ok=True)
with open("reports/algorithm_comparison.csv", "w", newline="") as f:
    w = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
    w.writeheader()
    w.writerows(rows)

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

fig, axes = plt.subplots(1, 3, figsize=(15, 4.5))
colors = ["#1c78b2", "#b8c2cf", "#0aa5a8", "#f5a31a", "#3440a8"]
for ax, idx, title in zip(axes, (1, 2, 3), ("Average states expanded", "Average time (ms)", "Average shift from requested time (min)")):
    ax.bar([s[0] for s in summary], [s[idx] for s in summary], color=colors)
    ax.set_title(title, fontsize=11)
    ax.tick_params(axis="x", labelrotation=25, labelsize=8)
    ax.grid(axis="y", alpha=0.3)
plt.tight_layout()
plt.savefig("reports/algorithm_comparison.png", dpi=150)
print("\nSaved reports/algorithm_comparison.csv and reports/algorithm_comparison.png")

if "--save" in sys.argv:
    from sqlalchemy import text
    from app.db import engine
    with engine.begin() as conn:
        for r in rows:
            conn.execute(text("""INSERT INTO AlgorithmRuns (algorithm, states_expanded, time_ms, result_quality)
                                 VALUES (:a, :s, :t, :q)"""),
                         {"a": r["algorithm"], "s": r["expanded"], "t": r["time_ms"], "q": r["shift_min"]})
        conn.execute(text("INSERT INTO ActivityLog (action, details) VALUES ('compare_algorithms', :d)"),
                     {"d": f"{len(rows)} runs saved"})
    print(f"Saved {len(rows)} runs to the AlgorithmRuns table.")
