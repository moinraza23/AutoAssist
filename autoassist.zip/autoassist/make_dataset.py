"""Training data generator. Creates data/emails_labeled.csv (synthetic, labeled emails)."""
import csv
import os
import random

random.seed(42)
N_PER_CLASS = 150

NAMES = ["Ali", "Sara", "Ahmed", "Fatima", "Usman", "Hina", "Bilal", "Ayesha", "Zain",
         "Maria", "Hassan", "Noor", "Omar", "Sana", "Faisal", "Rida", "Samad", "Moin"]
HUMAN_DOMAINS = ["gmail.com", "outlook.com", "iqra.edu.pk", "yahoo.com", "company.com"]
BOT_SENDERS = ["noreply@shop.com", "no-reply@news.com", "offers@store.com",
               "newsletter@brand.com", "recommendations@social.com", "info@promo.com",
               "noreply@accounts.google.com", "notifications@app.com"]
PORTAL_SENDERS = ["noreply@portal.iqra.edu.pk", "calendar-notification@google.com",
                  "noreply@lms.iqra.edu.pk"]
OPENERS = ["Hi", "Hello", "Dear", "Assalam o Alaikum", "Hey", "Good morning", ""]
CLOSERS = ["Thanks", "Regards", "Please reply.", "Let me know.", "Best wishes",
           "Sent from my iPhone", "JazakAllah", "", ""]
WHENS = ["tomorrow at 3 PM", "on Monday morning", "next week", "this Friday at 11 am",
         "on Wednesday afternoon", "today after lunch", "at 4 pm tomorrow", "sometime this week"]
DEADLINES = ["Friday", "next Monday", "tomorrow evening", "the end of this week",
             "15th November", "Thursday 5 pm", "midnight"]

BANK = {
    "meeting": {
        "subjects": ["Meeting request", "Meeting tomorrow", "Quick call?", "Schedule a meeting",
                     "Project discussion", "Availability for a call", "Zoom link", "Catch up",
                     "Appointment", "Re: meeting", "Sync up"],
        "cores": [
        'do you have time {w} for a short discussion',
        'I am setting up a project review {w}, can you join',
        'could we find a slot {w} to go over the report',
        'please let me know your availability {w} for the interview',
        'I have sent a calendar invite for {w}, please accept',
        'would it be possible to reschedule our session to {w}',
        'we need to sit together {w} and plan the next sprint',
        'free ho to {w} baat kar lete hain call par',"can we schedule a meeting {w}", "I would like to set up a call {w}",
                  "are you available {w} for a quick sync", "let us meet {w} to discuss the project",
                  "please confirm if {w} works for the meeting", "can we arrange a zoom call {w}",
                  "kal 3 baje meeting rakh lein", "aap free hain {w}? meeting karni hai",
                  "I want to book an appointment {w}", "the team meeting is moved to {w}, please confirm",
                  "urgent: the meeting starts in ten minutes, please join the call"],
    },
    "urgent": {
        "subjects": ["URGENT", "Urgent: action required", "Immediate attention", "Important",
                     "Deadline today", "ASAP", "High priority", "Need reply now", "Time sensitive",
                     "Critical issue"],
        "cores": [
        'need this resolved right now, everything is on hold',
        'please call me back immediately, it is an emergency',
        'the client is waiting for our answer, respond within the hour',
        'system outage in production, all hands needed right away',
        'your immediate action is required to avoid penalties today',
        'I have not heard back from you, this is now critical',
        'bohat zaroori kaam hai, abhi dekh lo please',
        'high priority escalation, please acknowledge asap',"this is urgent, please reply as soon as possible", "I need your response immediately",
                  "the deadline is today and we still need your input",
                  "urgent: the server is down, please check asap",
                  "important update that needs your attention right now",
                  "please respond today, this cannot wait", "jaldi reply karo, bohat zaroori hai",
                  "final reminder, last chance to respond before the deadline",
                  "critical issue in the project, need your help immediately",
                  "kindly treat this as high priority", "the meeting was cancelled, reply asap",
                  "urgent: please submit the report today, the deadline is tonight"],
    },
    "task": {
        "subjects": ["Assignment reminder", "Task update", "Lab report due", "Submission deadline",
                     "Homework", "Action required: report", "Please submit", "To do",
                     "Project deliverable", "Reminder"],
        "cores": [
        'the quiz preparation material has to be completed by {d}',
        'please fill in the feedback form and return it by {d}',
        'you are required to revise chapter five and submit notes by {d}',
        'kindly send the signed forms to the office before {d}',
        'your project proposal is pending, please upload it by {d}',
        'make sure the code is pushed to the repository by {d}',
        'is hafte ka lab task {d} tak mukammal kar dena',
        'we are still waiting for your part of the report, due {d}',"please submit the assignment by {d}", "reminder: the lab report is due on {d}",
                  "kindly complete the task and send it back by {d}",
                  "your homework for the database course is due {d}",
                  "do not forget to upload the project report before {d}",
                  "please review the document and share your feedback by {d}",
                  "the next assignment deadline is {d}, submit on the portal",
                  "please prepare the presentation slides for {d}",
                  "action item: update the spreadsheet and send it by {d}",
                  "assignment submit karni hai {d} tak",
                  "please send the meeting notes by {d}"],
    },
    "general": {
        "subjects": ["Hello", "Thanks", "FYI", "Notes", "Photos", "Congratulations", "Greetings",
                     "Sharing slides", "Update", "Hi there", "Re: yesterday"],
        "cores": [
        'it was great meeting everyone at the seminar',
        'just checking in to see how your semester is going',
        'attaching the minutes of last week for your records',
        'welcome to the group, glad to have you with us',
        'the results have been announced on the notice board',
        'thank you so much for the recommendation letter',
        'eid mubarak to you and your family',
        'wanted to let you know I reached home safely',"thank you for your email, I have received it", "just wanted to share the notes from class",
                  "hope you are doing well, sharing the photos from the trip",
                  "here is the document you asked for, no rush", "congratulations on your results",
                  "thanks for your help yesterday, really appreciated",
                  "FYI the library will be closed on Sunday", "happy birthday, wishing you a great year",
                  "I enjoyed our discussion, let us keep in touch",
                  "sharing the slides from the lecture for your reference",
                  "kya haal hai? bas hello kehna tha", "please find the attached file",
                  "thanks for the meeting yesterday, it was helpful"],
    },
    "spam": {
        "subjects": ["Flawless", "4 new image styles to try", "Big sale", "Your weekly digest",
                     "Security alert", "50% off", "Special offer for you", "You might like these",
                     "Newsletter", "Claim your reward", "This screams you"],
        "cores": [
        'tap to see your top picks and trending ideas this week',
        'your cart is waiting, complete your purchase and get free delivery',
        'congratulations, you have been selected for an exclusive reward',
        'we updated our privacy policy, no action is needed from you',
        'new sign-in from a Windows device, check activity if this was not you',
        'save up to 70 percent on electronics this weekend only',
        'join thousands of learners, enroll now with a special promotion',
        'watch the latest videos picked for you',"get 50% off on all items, limited time offer",
                  "4 new image styles to try, tap to explore now",
                  "recommendations just for you based on your recent activity",
                  "unsubscribe from this newsletter at any time",
                  "your weekly digest is ready, see what is trending",
                  "flash sale, shop now and save big",
                  "win a free gift card, click the link to claim your prize",
                  "security alert: new sign-in detected on your account",
                  "finish setting up your device to get the most out of it",
                  "someone saved your pin, see more ideas like this",
                  "your subscription is about to renew, manage your preferences",
                  "exclusive discount code inside, offer expires soon",
                  "urgent: our sale ends tonight, last chance to save",
                  "new post from a community you follow"],
    },
}


def pick_sender(cat):
    if cat == "spam":
        if random.random() < 0.08:
            return f"{random.choice(NAMES)} <info@{random.choice(HUMAN_DOMAINS)}>"
        return random.choice(BOT_SENDERS)
    r = random.random()
    if r < 0.10:
        return random.choice(PORTAL_SENDERS)
    name = random.choice(NAMES)
    return f"{name} <{name.lower()}@{random.choice(HUMAN_DOMAINS)}>"


def make_row(cat):
    b = BANK[cat]
    ci = random.randrange(len(b["cores"]))
    core = b["cores"][ci].format(w=random.choice(WHENS), d=random.choice(DEADLINES))
    parts = [random.choice(OPENERS), core.capitalize() + ".", ""]
    if random.random() < 0.07:  # noise: a sentence borrowed from another class
        other = random.choice([c for c in BANK if c != cat])
        borrowed = random.choice(BANK[other]["cores"]).format(w=random.choice(WHENS), d=random.choice(DEADLINES))
        parts.insert(2, borrowed.capitalize() + ".")
    parts.append(random.choice(CLOSERS))
    body = " ".join(p for p in parts if p).strip()
    return [pick_sender(cat), random.choice(b["subjects"]), body, cat, f"{cat}_{ci}"]


os.makedirs("data", exist_ok=True)
rows = [make_row(c) for c in BANK for _ in range(N_PER_CLASS)]
random.shuffle(rows)
with open("data/emails_labeled.csv", "w", newline="", encoding="utf-8") as f:
    w = csv.writer(f)
    w.writerow(["sender", "subject", "body", "category", "group"])
    w.writerows(rows)
print(f"Saved {len(rows)} labeled emails to data/emails_labeled.csv")
