from googleapiclient.discovery import build
from app.google_auth import get_credentials

service = build("gmail", "v1", credentials=get_credentials())
res = service.users().messages().list(userId="me", maxResults=5).execute()

for m in res.get("messages", []):
    msg = service.users().messages().get(
        userId="me", id=m["id"], format="metadata",
        metadataHeaders=["From", "Subject"]).execute()
    h = {x["name"]: x["value"] for x in msg["payload"]["headers"]}
    print(h.get("From"), "|", h.get("Subject"))