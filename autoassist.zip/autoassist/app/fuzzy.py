"""A small Mamdani fuzzy inference engine (written from scratch) and the two fuzzy systems used by AutoAssist.

1. priority_system : deadline closeness + sender importance + waiting time  ->  priority (0-100)
2. reminder_system : hours left + priority                                  ->  reminder interval (minutes)
"""


def trap(a, b, c, d):
    """Trapezoid membership function (a<=b<=c<=d). A triangle is trap(a, b, b, c)."""
    def mu(x):
        if x < a or x > d:
            return 0.0
        if b <= x <= c:
            return 1.0
        return (x - a) / (b - a) if x < b else (d - x) / (d - c)
    return mu


def tri(a, b, c):
    return trap(a, b, b, c)


class FuzzySystem:
    def __init__(self, inputs, output, universe, rules):
        self.inputs = inputs      # {"variable": {"label": membership_function}}
        self.output = output      # {"label": membership_function}
        self.universe = universe  # list of x values the output is evaluated on
        self.rules = rules        # [({"variable": "label", ...}, "output_label"), ...]

    def infer(self, **values):
        """Returns (crisp_value, fired_rules). AND = min, aggregation = max, defuzzification = centroid."""
        strengths = []
        for cond, out in self.rules:
            s = min(self.inputs[var][label](values[var]) for var, label in cond.items())
            strengths.append((s, cond, out))
        num = den = 0.0
        for x in self.universe:
            mu = max((min(s, self.output[out](x)) for s, _, out in strengths), default=0.0)
            num += x * mu
            den += mu
        crisp = num / den if den > 0 else (self.universe[0] + self.universe[-1]) / 2
        fired = [(s, " AND ".join(f"{v.replace('_', ' ')} is {l}" for v, l in cond.items()) + f"  ->  {out}")
                 for s, cond, out in strengths if s > 0]
        return crisp, sorted(fired, reverse=True)


# ------------------------------------------------------------------ system 1: email priority
priority_system = FuzzySystem(
    inputs={
        "deadline_hours": {"near": trap(0, 0, 6, 24), "medium": tri(12, 48, 96), "far": trap(72, 120, 168, 168)},
        "importance": {"low": trap(0, 0, 2, 5), "medium": tri(3, 5.5, 8), "high": trap(6, 8, 10, 10)},
        "waiting_hours": {"short": trap(0, 0, 6, 18), "medium": tri(12, 30, 54), "long": trap(36, 54, 72, 72)},
    },
    # five output levels, so emails with different situations get clearly different scores
    output={"very_low": trap(0, 0, 5, 20), "low": tri(10, 25, 40), "medium": tri(30, 50, 70),
            "high": tri(60, 75, 90), "critical": trap(80, 92, 100, 100)},
    universe=list(range(0, 101)),
    rules=[
        ({"deadline_hours": "near", "importance": "high"}, "critical"),
        ({"deadline_hours": "near", "importance": "medium"}, "high"),
        ({"deadline_hours": "near", "importance": "low"}, "medium"),
        ({"deadline_hours": "medium", "importance": "high"}, "high"),
        ({"deadline_hours": "medium", "importance": "medium"}, "medium"),
        ({"deadline_hours": "medium", "importance": "low"}, "low"),
        ({"deadline_hours": "far", "importance": "high"}, "medium"),
        ({"deadline_hours": "far", "importance": "medium"}, "low"),
        ({"deadline_hours": "far", "importance": "low"}, "very_low"),
        ({"waiting_hours": "long", "importance": "high"}, "high"),
        ({"waiting_hours": "long", "importance": "medium"}, "medium"),
        ({"waiting_hours": "long", "importance": "low"}, "low"),
        ({"waiting_hours": "medium", "importance": "high"}, "medium"),
        ({"waiting_hours": "short", "deadline_hours": "far"}, "very_low"),
    ],
)

# ------------------------------------------------------------------ system 2: reminder interval
reminder_system = FuzzySystem(
    inputs={
        "hours_left": {"near": trap(0, 0, 3, 12), "soon": tri(6, 18, 36),
                       "medium": tri(24, 60, 96), "far": trap(72, 120, 168, 168)},
        "priority": {"low": trap(0, 0, 20, 45), "medium": tri(25, 50, 75), "high": trap(55, 80, 100, 100)},
    },
    output={"very_frequent": trap(10, 10, 15, 30), "frequent": tri(20, 35, 60), "normal": tri(50, 90, 130),
            "rare": tri(110, 160, 210), "very_rare": trap(180, 220, 240, 240)},
    universe=list(range(10, 241, 5)),
    rules=[
        ({"hours_left": "near", "priority": "high"}, "very_frequent"),
        ({"hours_left": "near", "priority": "medium"}, "very_frequent"),
        ({"hours_left": "near", "priority": "low"}, "frequent"),
        ({"hours_left": "soon", "priority": "high"}, "frequent"),
        ({"hours_left": "soon", "priority": "medium"}, "frequent"),
        ({"hours_left": "soon", "priority": "low"}, "normal"),
        ({"hours_left": "medium", "priority": "high"}, "normal"),
        ({"hours_left": "medium", "priority": "medium"}, "normal"),
        ({"hours_left": "medium", "priority": "low"}, "rare"),
        ({"hours_left": "far", "priority": "high"}, "rare"),
        ({"hours_left": "far", "priority": "medium"}, "very_rare"),
        ({"hours_left": "far", "priority": "low"}, "very_rare"),
    ],
)


def _clip(x, lo, hi):
    return max(lo, min(hi, x))


def fuzzy_priority(deadline_hours, importance, waiting_hours):
    """Returns (score 0-100, fired rules)."""
    return priority_system.infer(deadline_hours=_clip(deadline_hours, 0, 168),
                                 importance=_clip(importance, 0, 10),
                                 waiting_hours=_clip(waiting_hours, 0, 72))


def priority_label(score):
    return "Critical" if score >= 85 else "High" if score >= 60 else "Medium" if score >= 35 else "Low"


def reminder_interval(hours_left, priority=50):
    """Minutes between two reminders (rounded to 5). Smaller = more frequent."""
    value, _ = reminder_system.infer(hours_left=_clip(hours_left, 0, 168),
                                     priority=_clip(priority if priority is not None else 50, 0, 100))
    return int(round(value / 5) * 5)
