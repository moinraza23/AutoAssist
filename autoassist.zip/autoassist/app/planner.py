"""Connects the genetic algorithm to a user's real data: meeting requests, reminders (tasks) and the calendar."""
from datetime import datetime

from sqlalchemy import text

from app import calendar_service, pipeline
from app.db import engine
from app.extract import detect_intent, extract_datetime
from app.genetic import Item, Problem, metrics, run_ga, run_greedy, run_random
from app.reminders import list_reminders


def _dt(v):
    return datetime.fromisoformat(v) if isinstance(v, str) else v


def build_items(user_id, now=None, task_minutes=60):
    """Meetings that still wait for a time + active reminders as work blocks."""
    now = now or datetime.now()
    with engine.connect() as conn:
        rows = conn.execute(text("""SELECT email_id, sender, subject, body, priority_score FROM Emails
                                    WHERE user_id = :u AND category = 'meeting' ORDER BY email_id"""), {"u": user_id}).fetchall()
        booked = {r[0] for r in conn.execute(text("SELECT email_id FROM Meetings WHERE user_id = :u"), {"u": user_id}) if r[0]}
    skip = booked | pipeline._processed_ids(user_id, "meeting_noted")
    items = []
    for r in rows:
        if r.email_id in skip:
            continue
        body = f"{r.subject or ''}. {(r.body or '')[:1500]}"
        if detect_intent(body) in ("cancel", "confirm"):
            continue
        info = extract_datetime(body, now)
        items.append(Item(len(items), r.subject or "Meeting", "meeting", info["duration_min"],
                          float(r.priority_score) if r.priority_score is not None else 50.0,
                          preferred=info["start"], meta={"email_id": r.email_id, "sender": r.sender}))
    for rem in list_reminders(user_id=user_id):
        deadline = _dt(rem.deadline)
        if deadline <= now:
            continue
        items.append(Item(len(items), rem.task, "task", task_minutes,
                          float(rem.priority) if rem.priority is not None else 50.0,
                          deadline=deadline, meta={"reminder_id": rem.reminder_id}))
    return items


def make_plan(user_id, busy, now=None, days=5, task_minutes=60, seed=7):
    """Runs the genetic algorithm, a greedy planner and random search on the same problem."""
    now = now or datetime.now()
    items = build_items(user_id, now, task_minutes)
    problem = Problem(items, busy, now, days)
    ga = run_ga(problem, seed=seed)
    greedy = run_greedy(problem)
    rnd = run_random(problem, ga["evaluations"], seed=seed)
    results = {}
    for name, r in (("Genetic Algorithm", ga), ("Greedy", greedy), ("Random search", rnd)):
        results[name] = {**r, **metrics(problem, r["genes"]), "rows": problem.describe(r["genes"])}
    best = "Genetic Algorithm" if results["Genetic Algorithm"]["cost"] <= results["Greedy"]["cost"] + 1e-9 else "Greedy"
    return {"items": items, "problem": problem, "results": results, "best": best, "days": days}


def apply_plan(user_id, plan, method, add_tasks=True):
    """Puts the chosen plan into Google Calendar. Meetings are also stored in the Meetings table."""
    rows = [r for r in plan["results"][method]["rows"] if r["start"] is not None]
    meetings = tasks = 0
    for r in rows:
        if r["kind"] == "meeting":
            calendar_service.create_event(r["title"], r["start"], r["end"], f"Requested by {r['meta'].get('sender', '')}", user_id=user_id)
            with engine.begin() as conn:
                conn.execute(text("""INSERT INTO Meetings (user_id, email_id, title, start_time, end_time, participants, algorithm_used)
                                     VALUES (:u, :i, :t, :s, :e, :p, :a)"""),
                             {"u": user_id, "i": r["meta"].get("email_id"), "t": r["title"], "s": r["start"], "e": r["end"],
                              "p": r["meta"].get("sender"), "a": f"{method} (weekly planner)"})
            meetings += 1
        elif add_tasks:
            calendar_service.create_event(f"Work: {r['title']}", r["start"], r["end"], "Planned by AutoAssist", user_id=user_id)
            tasks += 1
    with engine.begin() as conn:
        for name, res in plan["results"].items():
            conn.execute(text("""INSERT INTO AlgorithmRuns (algorithm, states_expanded, time_ms, result_quality)
                                 VALUES (:a, :s, :t, :q)"""),
                         {"a": f"{name} (weekly planner)", "s": res["evaluations"], "t": res["time_ms"], "q": res["cost"]})
        pipeline._log(conn, user_id, "apply_plan", f"{method}: {meetings} meetings, {tasks} work blocks")
    return meetings, tasks
