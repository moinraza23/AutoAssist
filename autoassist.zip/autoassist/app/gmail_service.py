import base64
import os
from email.mime.text import MIMEText
from email.utils import parseaddr, parsedate_to_datetime

from dotenv import load_dotenv
from googleapiclient.discovery import build

from app.google_auth import get_credentials

load_dotenv()


def get_service(user_id=None):
    return build("gmail", "v1", credentials=get_credentials(user_id), cache_discovery=False)


def _extract_body(payload):
    """Plain-text body of an email (looks inside nested parts)."""
    if payload.get("mimeType") == "text/plain" and payload["body"].get("data"):
        return base64.urlsafe_b64decode(payload["body"]["data"]).decode("utf-8", errors="ignore")
    for part in payload.get("parts", []) or []:
        text = _extract_body(part)
        if text:
            return text
    return ""


def fetch_recent(max_results=20, user_id=None):
    service = get_service(user_id)
    res = service.users().messages().list(userId="me", maxResults=max_results, labelIds=["INBOX"]).execute()
    emails = []
    for m in res.get("messages", []):
        msg = service.users().messages().get(userId="me", id=m["id"], format="full").execute()
        headers = {h["name"]: h["value"] for h in msg["payload"]["headers"]}
        try:
            received = parsedate_to_datetime(headers.get("Date")).replace(tzinfo=None)
        except Exception:
            received = None
        emails.append({"gmail_id": msg["id"], "thread_id": msg.get("threadId"),
                       "sender": headers.get("From", ""), "subject": headers.get("Subject", ""),
                       "body": _extract_body(msg["payload"])[:5000], "received_at": received})
    return emails


def send_reply(to_header, subject, body, thread_id=None, user_id=None):
    override = os.getenv("SEND_OVERRIDE")          # development safety: send everything to one test address
    to_addr = override if override else parseaddr(to_header)[1]
    subject = subject or ""
    msg = MIMEText(body)
    msg["To"] = to_addr
    msg["Subject"] = subject if subject.lower().startswith("re:") else "Re: " + subject
    payload = {"raw": base64.urlsafe_b64encode(msg.as_bytes()).decode()}
    if thread_id and not override:
        payload["threadId"] = thread_id
    return get_service(user_id).users().messages().send(userId="me", body=payload).execute()
