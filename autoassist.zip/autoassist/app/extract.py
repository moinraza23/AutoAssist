"""Pulls the requested date/time, duration and intent out of an email (English + Roman Urdu)."""
import re
from datetime import datetime, timedelta

WEEKDAYS = ["monday", "tuesday", "wednesday", "thursday", "friday", "saturday", "sunday"]
MONTHS = {"jan": 1, "feb": 2, "mar": 3, "apr": 4, "may": 5, "jun": 6, "jul": 7, "aug": 8,
          "sep": 9, "oct": 10, "nov": 11, "dec": 12}
MON = "|".join(MONTHS)
PART_OF_DAY = {"morning": (10, 0), "afternoon": (14, 0), "evening": (18, 0), "night": (20, 0)}


def _normalize(text):
    """Lower-cases and converts common Roman Urdu words to their English meaning."""
    t = (text or "").lower()
    t = re.sub(r"\bparson\b", "day after tomorrow", t)
    t = re.sub(r"\baaj\b", "today", t)
    if re.search(r"\bkal\b", t):
        past = re.search(r"\b(tha|thi|the|gaya|gayi|hua|hui)\b", t)
        t = re.sub(r"\bkal\b", "yesterday" if past else "tomorrow", t)
    for ur, en in (("subah", "morning"), ("dopahar", "afternoon"), ("shaam", "evening"), ("raat", "night")):
        t = re.sub(rf"\b{ur}\b", en, t)
    t = re.sub(r"\bbaje\b", "o'clock", t)
    return t


def _next_year_if_past(day, month, year, base):
    if year:
        year = year + 2000 if year < 100 else year
        return datetime(year, month, day)
    d = datetime(base.year, month, day)
    return d if d >= base else datetime(base.year + 1, month, day)


def _find_date(t, now):
    """Returns (date at 00:00 or None, vague)."""
    base = now.replace(hour=0, minute=0, second=0, microsecond=0)
    try:
        if re.search(r"\bday after tomorrow\b", t):
            return base + timedelta(days=2), False
        if re.search(r"\btomorrow\b", t):
            return base + timedelta(days=1), False
        if re.search(r"\b(today|tonight)\b", t):
            return base, False
        m = re.search(r"\b(\d{4})-(\d{2})-(\d{2})\b", t)
        if m:
            return datetime(int(m[1]), int(m[2]), int(m[3])), False
        m = re.search(rf"\b(\d{{1,2}})(?:st|nd|rd|th)?\s*(?:of\s+)?({MON})[a-z]*\b(?:,?\s*(\d{{4}}))?", t)
        if m:
            return _next_year_if_past(int(m[1]), MONTHS[m[2]], int(m[3]) if m[3] else None, base), False
        m = re.search(rf"\b({MON})[a-z]*\.?\s+(\d{{1,2}})(?:st|nd|rd|th)?\b(?:,?\s*(\d{{4}}))?", t)
        if m:
            return _next_year_if_past(int(m[2]), MONTHS[m[1]], int(m[3]) if m[3] else None, base), False
        m = re.search(r"\b(\d{1,2})/(\d{1,2})(?:/(\d{2,4}))?\b", t)  # day/month/year
        if m:
            return _next_year_if_past(int(m[1]), int(m[2]), int(m[3]) if m[3] else None, base), False
        m = re.search(rf"\b(next|this|coming)?\s*({'|'.join(WEEKDAYS)})\b", t)
        if m:
            idx = WEEKDAYS.index(m[2])
            if m[1] == "next":  # weekday of the following calendar week
                return base + timedelta(days=(7 - base.weekday()) + idx), False
            ahead = (idx - base.weekday()) % 7 or 7
            return base + timedelta(days=ahead), False
        if re.search(r"\bend of (this|the) week\b", t):
            ahead = (4 - base.weekday()) % 7
            return base + timedelta(days=ahead), False
        if re.search(r"\bnext week\b", t):
            return base + timedelta(days=7 - base.weekday()), True
        if re.search(r"\bthis week\b", t):
            return base + timedelta(days=1), True
    except ValueError:  # impossible date such as 31 Feb
        return None, False
    return None, False


def _to_24h(h, ap=None, part=None):
    if ap:
        ap = ap.replace(".", "")
        return (h % 12) + (12 if ap == "pm" else 0)
    if h > 12:
        return h
    if part == "morning":
        return 0 if h == 12 else h
    if part in ("afternoon", "evening", "night"):
        return h if h == 12 else h + 12
    if 1 <= h <= 6:   # business-hours guess: "at 3" means 3 PM
        return h + 12
    return h          # 7-11 stay in the morning, 12 stays noon


def _find_time(t):
    """Returns ((hour, minute) or None, approx)."""
    part = next((p for p in PART_OF_DAY if re.search(rf"\b{p}\b", t)), None)
    m = re.search(r"\b(\d{1,2})(?::(\d{2}))?\s*(a\.?m\.?|p\.?m\.?)(?!\w)", t)
    if m and int(m[1]) <= 12:
        return (_to_24h(int(m[1]), m[3][0] + "m"), int(m[2] or 0)), False
    m = re.search(r"\b(\d{1,2}):(\d{2})\b", t)
    if m and int(m[1]) <= 23 and int(m[2]) <= 59:
        return (_to_24h(int(m[1]), None, part), int(m[2])), False
    m = re.search(r"\b(\d{1,2})\s*o'clock\b", t) or re.search(r"\b(?:at|around|@)\s*(\d{1,2})\b(?!\s*(?:st|nd|rd|th|%|:|/|-))", t)
    if m and 1 <= int(m[1]) <= 23:
        return (_to_24h(int(m[1]), None, part), 0), False
    if re.search(r"\bnoon\b", t):
        return (12, 0), False
    if re.search(r"\bmidnight\b", t):
        return (23, 59), False
    if part:
        return PART_OF_DAY[part], True
    return None, False


def extract_duration(text, default=60):
    t = (text or "").lower()
    m = re.search(r"\b(\d{1,3})\s*(?:min|mins|minutes)\b", t)
    if m:
        return max(5, min(int(m[1]), 480))
    m = re.search(r"\b(\d{1,2})\s*(?:hour|hours|hr|hrs)\b", t)
    if m:
        return max(5, min(int(m[1]) * 60, 480))
    if re.search(r"\bhalf an hour\b", t):
        return 30
    if re.search(r"\b(an|one) hour\b", t):
        return 60
    return default


def extract_datetime(text, now=None, default_time=(10, 0)):
    """Finds the date and time mentioned in `text`.
    Returns dict: start (datetime or None), has_date, has_time, approx, vague, duration_min."""
    now = now or datetime.now()
    t = _normalize(text)
    date, vague = _find_date(t, now)
    time, approx = _find_time(t)
    out = {"start": None, "has_date": date is not None, "has_time": time is not None,
           "approx": approx or (date is not None and time is None) or vague, "vague": vague,
           "duration_min": extract_duration(text)}
    if date is None and time is None:
        return out
    if date is None:  # time only: today if it is still ahead, otherwise tomorrow
        date = now.replace(hour=0, minute=0, second=0, microsecond=0)
        if date.replace(hour=time[0], minute=time[1]) <= now + timedelta(minutes=30):
            date += timedelta(days=1)
    h, mi = time or default_time
    out["start"] = date.replace(hour=h, minute=mi)
    return out


def detect_intent(text):
    """request / reschedule / cancel / confirm"""
    t = (text or "").lower()
    if re.search(r"\b(cancel|cancelled|canceled|call off|called off|cannot make it|can't make it)\b", t):
        return "cancel"
    if re.search(r"\b(reschedule|re-schedule|postpone|postponed|moved to|shifted to|change the time|another time|different time)\b", t):
        return "reschedule"
    if re.search(r"\b(confirmed|see you|works for me|sounds good|i accept|accepted)\b", t):
        return "confirm"
    return "request"
