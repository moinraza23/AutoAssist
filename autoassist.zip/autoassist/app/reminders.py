from datetime import datetime, timedelta

from sqlalchemy import text

from app.accounts import default_user_id
from app.db import engine


def _uid(user_id):
    return user_id or default_user_id()


def _log(conn, user_id, action, details):
    conn.execute(text("INSERT INTO ActivityLog (user_id, action, details) VALUES (:u, :a, :d)"),
                 {"u": user_id, "a": action, "d": details})


def add_reminder(task, deadline, priority=None, frequency_minutes=60, user_id=None):
    uid = _uid(user_id)
    with engine.begin() as conn:
        conn.execute(text("""INSERT INTO Reminders (user_id, task, deadline, priority, frequency_minutes, status)
                             VALUES (:u, :t, :d, :p, :f, 'active')"""),
                     {"u": uid, "t": task, "d": deadline, "p": priority, "f": frequency_minutes})
        _log(conn, uid, "add_reminder", task)


def list_reminders(status="active", user_id=None):
    with engine.connect() as conn:
        rows = conn.execute(text("""SELECT reminder_id, task, deadline, priority, frequency_minutes, status
                                    FROM Reminders WHERE status = :s AND user_id = :u"""),
                            {"s": status, "u": _uid(user_id)}).fetchall()
    return sorted(rows, key=lambda r: r.deadline)


def mark_done(reminder_id, user_id=None):
    uid = _uid(user_id)
    with engine.begin() as conn:
        conn.execute(text("UPDATE Reminders SET status='done' WHERE reminder_id=:i AND user_id=:u"),
                     {"i": reminder_id, "u": uid})
        _log(conn, uid, "reminder_done", str(reminder_id))


def delete_reminder(reminder_id, user_id=None):
    uid = _uid(user_id)
    with engine.begin() as conn:
        conn.execute(text("DELETE FROM Reminders WHERE reminder_id=:i AND user_id=:u"), {"i": reminder_id, "u": uid})
        _log(conn, uid, "delete_reminder", str(reminder_id))


def due_reminders(window_hours=24, user_id=None):
    """Active reminders whose deadline is inside the window and whose repeat interval has passed.
    user_id=None means all users (used by the desktop notifier)."""
    now = datetime.now()
    sql = """SELECT reminder_id, user_id, task, deadline, frequency_minutes, last_notified
             FROM Reminders WHERE status = 'active' AND deadline <= :cut"""
    params = {"cut": now + timedelta(hours=window_hours)}
    if user_id:
        sql += " AND user_id = :u"
        params["u"] = user_id
    with engine.connect() as conn:
        rows = conn.execute(text(sql), params).fetchall()
    due = []
    for r in rows:
        last = datetime.fromisoformat(r.last_notified) if isinstance(r.last_notified, str) else r.last_notified
        if last is None or (now - last).total_seconds() / 60 >= (r.frequency_minutes or 60):
            due.append(r)
    return due


def mark_notified(reminder_id):
    with engine.begin() as conn:
        conn.execute(text("UPDATE Reminders SET last_notified=:n WHERE reminder_id=:i"),
                     {"n": datetime.now(), "i": reminder_id})
