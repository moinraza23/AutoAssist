"""Encrypts Gmail tokens before they are stored in the database (Fernet / AES)."""
import os

from cryptography.fernet import Fernet, InvalidToken
from dotenv import load_dotenv

load_dotenv()


class SecurityError(Exception):
    pass


def _fernet():
    key = os.getenv("TOKEN_KEY", "").strip()
    if not key:
        raise SecurityError("TOKEN_KEY is missing in .env (see the setup steps).")
    try:
        return Fernet(key.encode())
    except Exception as exc:
        raise SecurityError("TOKEN_KEY in .env is not a valid key.") from exc


def encrypt(text):
    return _fernet().encrypt(text.encode()).decode()


def decrypt(token):
    try:
        return _fernet().decrypt(token.encode()).decode()
    except InvalidToken as exc:
        raise SecurityError("Stored token cannot be decrypted. Was TOKEN_KEY changed?") from exc
