from datetime import datetime, timedelta

from app.calendar_service import PKT

WORK_START, WORK_END = 9, 17     # 9 AM se 5 PM
LUNCH = (13, 14)                 # 1 PM se 2 PM break
STEP = 30                        # har 30 minute par slot check


def overlaps(a_start, a_end, b_start, b_end):
    return a_start < b_end and b_start < a_end


def _day_limits(day):
    return (day.replace(hour=WORK_START, minute=0, second=0, microsecond=0),
            day.replace(hour=WORK_END, minute=0, second=0, microsecond=0),
            day.replace(hour=LUNCH[0], minute=0, second=0, microsecond=0),
            day.replace(hour=LUNCH[1], minute=0, second=0, microsecond=0))


def check_slot(busy, start, duration_min=60, now=None):
    """Returns (True, '') if the slot is usable, otherwise (False, reason)."""
    now = now or datetime.now(PKT).replace(tzinfo=None)
    end = start + timedelta(minutes=duration_min)
    work_s, work_e, lunch_s, lunch_e = _day_limits(start)
    if start <= now + timedelta(minutes=30):
        return False, "that time has already passed or is too close"
    if start.weekday() >= 5:
        return False, "it falls on a weekend"
    if start < work_s or end > work_e:
        return False, "it is outside working hours (9 AM - 5 PM)"
    if overlaps(start, end, lunch_s, lunch_e):
        return False, "it overlaps the lunch break"
    for bs, be in busy:
        if overlaps(start, end, bs, be):
            return False, f"you already have something from {bs:%I:%M %p} to {be:%I:%M %p}"
    return True, ""


def _free_slots(busy, duration_min, start_day, days, now):
    out = []
    dur = timedelta(minutes=duration_min)
    for d in range(days + 1):
        day = (start_day + timedelta(days=d)).replace(hour=0, minute=0, second=0, microsecond=0)
        if day.weekday() >= 5:
            continue
        t = day.replace(hour=WORK_START)
        while t + dur <= day.replace(hour=WORK_END):
            if check_slot(busy, t, duration_min, now)[0]:
                out.append((t, t + dur))
            t += timedelta(minutes=STEP)
    return out


def suggest_slots(busy, duration_min=60, n=3, days=7):
    """First-fit: the earliest free slots from now."""
    now = datetime.now(PKT).replace(tzinfo=None)
    return _free_slots(busy, duration_min, now, days, now)[:n]


def nearest_slots(busy, target, duration_min=60, n=3, days=14):
    """Nearest-fit: free slots closest in time to the time the sender asked for."""
    now = datetime.now(PKT).replace(tzinfo=None)
    first = max(now, target - timedelta(days=3))
    slots = _free_slots(busy, duration_min, first, days + 3, now)
    slots.sort(key=lambda s: abs(s[0] - target))
    return sorted(slots[:n])
