from datetime import datetime, timedelta, timezone

from googleapiclient.discovery import build

from app.google_auth import get_credentials

PKT = timezone(timedelta(hours=5))  # Pakistan time


def get_calendar(user_id=None):
    return build("calendar", "v3", credentials=get_credentials(user_id), cache_discovery=False)


def _parse(t):
    if "dateTime" in t:
        return datetime.fromisoformat(t["dateTime"]).astimezone(PKT).replace(tzinfo=None)
    return datetime.fromisoformat(t["date"])  # all-day event


def get_busy(days=7, user_id=None):
    now = datetime.now(PKT)
    res = get_calendar(user_id).events().list(
        calendarId="primary", timeMin=now.isoformat(), timeMax=(now + timedelta(days=days)).isoformat(),
        singleEvents=True, orderBy="startTime").execute()
    return [(_parse(ev["start"]), _parse(ev["end"])) for ev in res.get("items", []) if ev.get("status") != "cancelled"]


def create_event(title, start, end, description="", user_id=None):
    body = {"summary": title, "description": description,
            "start": {"dateTime": start.isoformat(), "timeZone": "Asia/Karachi"},
            "end": {"dateTime": end.isoformat(), "timeZone": "Asia/Karachi"}}
    return get_calendar(user_id).events().insert(calendarId="primary", body=body).execute()
