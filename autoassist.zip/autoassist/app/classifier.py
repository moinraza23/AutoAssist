"""ML email classifier (TF-IDF + Naive Bayes / Logistic Regression) with a rule-based fallback."""
import os
import re

import joblib

from app.rules import categorize as rule_categorize

MODEL_PATH = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
                          "models", "email_classifier.joblib")
THRESHOLD = 0.45  # below this confidence we fall back to the Phase 1 keyword rules
_model = None


def build_text(sender, subject, body):
    """Turns one email into the text the model learns from (sender tokens + subject x2 + body)."""
    sender = (sender or "").lower()
    m = re.search(r"<([^>]+)>", sender)
    addr = m.group(1) if m else sender
    local, _, domain = addr.partition("@")
    subject = subject or ""
    return f"sender_{local} domain_{domain} {subject} {subject} {(body or '')[:1500]}"


def _load():
    global _model
    if _model is None and os.path.exists(MODEL_PATH):
        _model = joblib.load(MODEL_PATH)
    return _model


def classify(sender, subject, body):
    """Returns (category, confidence, method). method is 'ml' or 'rules'."""
    model = _load()
    if model is None:
        return rule_categorize(sender, subject, body), None, "rules"
    proba = model.predict_proba([build_text(sender, subject, body)])[0]
    i = int(proba.argmax())
    conf = float(proba[i])
    if conf < THRESHOLD:
        return rule_categorize(sender, subject, body), conf, "rules"
    return str(model.classes_[i]), conf, "ml"


if __name__ == "__main__":
    samples = [
        ("Sara <sara@gmail.com>", "Quick call?", "Hi Moin, can we meet tomorrow at 3 PM to discuss the project?"),
        ("Prof <prof@iqra.edu.pk>", "Lab report due", "Please submit the lab report by Friday on the portal."),
        ("Ali <ali@gmail.com>", "URGENT", "I need your reply immediately, the server is down."),
        ("Pinterest <recommendations@inspire.pinterest.com>", "Flawless", "Ideas we think you will love"),
        ("Hina <hina@gmail.com>", "Hello", "Sharing the notes from class, no rush."),
    ]
    for s in samples:
        print(f"{classify(*s)}  <-  {s[1]}")
