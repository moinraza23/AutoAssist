from email.utils import parseaddr

TEMPLATES = {
    "meeting": ("Hello {name},\n\nThank you for reaching out about the meeting. "
                "I have received your request and will confirm a suitable time shortly.\n\nBest regards"),
    "urgent": ("Hello {name},\n\nThank you for your message. I understand this is time-sensitive "
               "and will get back to you as soon as possible.\n\nBest regards"),
    "task": ("Hello {name},\n\nThank you for the update. I have noted this task and "
             "will make sure it is completed on time.\n\nBest regards"),
    "general": ("Hello {name},\n\nThank you for your email. I have received it and "
                "will respond in detail soon.\n\nBest regards"),
}

def sender_name(sender):
    name, addr = parseaddr(sender)
    return name or addr.split("@")[0]

def make_reply(category, sender, my_name=None):
    """Template reply. Signed with my_name (the account owner's name) when it is given."""
    t = TEMPLATES.get(category)
    if not t:
        return None
    return t.format(name=sender_name(sender)) + (f",\n{my_name}" if my_name else "")
