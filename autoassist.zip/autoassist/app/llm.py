"""One function, generate(), that talks to Gemini or Claude (chosen in .env)."""
import os

from dotenv import load_dotenv

load_dotenv()


class LLMError(Exception):
    pass


def generate(system, prompt, max_tokens=1000):
    provider = os.getenv("LLM_PROVIDER", "gemini").strip().lower()
    if provider == "mock":
        return _mock(prompt)
    if provider == "gemini":
        return _gemini(system, prompt, max_tokens)
    if provider == "claude":
        return _claude(system, prompt, max_tokens)
    raise LLMError(f"Unknown LLM_PROVIDER '{provider}' (use gemini, claude or mock)")


def _gemini(system, prompt, max_tokens):
    key, model = os.getenv("GEMINI_API_KEY"), os.getenv("GEMINI_MODEL")
    if not key or not model:
        raise LLMError("GEMINI_API_KEY or GEMINI_MODEL is missing in .env")
    try:
        from google import genai
        from google.genai import types
        client = genai.Client(api_key=key)
        resp = client.models.generate_content(
            model=model, contents=prompt,
            config=types.GenerateContentConfig(system_instruction=system,
                                               max_output_tokens=max_tokens, temperature=0.4))
        text = (resp.text or "").strip()
    except Exception as exc:
        raise LLMError(f"Gemini error: {exc}") from exc
    if not text:
        raise LLMError("Gemini returned an empty reply")
    return text


def _claude(system, prompt, max_tokens):
    key, model = os.getenv("ANTHROPIC_API_KEY"), os.getenv("CLAUDE_MODEL", "claude-haiku-5-5")
    if not key:
        raise LLMError("ANTHROPIC_API_KEY is missing in .env")
    try:
        import anthropic
        client = anthropic.Anthropic(api_key=key)
        msg = client.messages.create(model=model, max_tokens=max_tokens, system=system,
                                     messages=[{"role": "user", "content": prompt}])
        text = "".join(b.text for b in msg.content if getattr(b, "type", "") == "text").strip()
    except Exception as exc:
        raise LLMError(f"Claude error: {exc}") from exc
    if not text:
        raise LLMError("Claude returned an empty reply")
    return text


def _mock(prompt):
    """Offline test mode: no API key needed. Shows what the pipeline would send."""
    line = next((l for l in prompt.splitlines() if l.startswith("- Requested time")), "")
    extra = f" {line[2:]}." if line else ""
    return ("Hello,\n\n[MOCK REPLY] Thank you for your email. I have read it carefully and "
            f"will respond properly.{extra}\n\nBest regards")
