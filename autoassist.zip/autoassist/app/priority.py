"""Turns an email into the three fuzzy inputs and returns its priority."""
import os
from datetime import datetime
from email.utils import parseaddr

from app.extract import extract_datetime
from app.fuzzy import fuzzy_priority, priority_label

BOT_WORDS = ("noreply", "no-reply", "newsletter", "notifications", "recommendations", "donotreply")
FREE_MAIL = {"gmail.com", "outlook.com", "yahoo.com", "hotmail.com", "live.com"}


def sender_importance(sender):
    """0-10. VIP list (VIP_SENDERS in .env) > university > organisation > free mail > automated."""
    addr = parseaddr(sender or "")[1].lower()
    domain = addr.split("@")[-1]
    vips = [v.strip().lower() for v in os.getenv("VIP_SENDERS", "").split(",") if v.strip()]
    if addr in vips:
        return 10
    if any(w in addr for w in BOT_WORDS):
        return 1
    if domain.endswith("edu.pk") or domain.endswith(".edu"):
        return 8
    if domain in FREE_MAIL:
        return 5
    return 6


def email_priority(sender, subject, body, category, received_at=None, now=None):
    """Returns {'score', 'label', 'inputs', 'fired'}."""
    now = now or datetime.now()
    if category == "spam":
        return {"score": 0.0, "label": "Low", "inputs": {}, "fired": []}
    text = f"{subject or ''}. {(body or '')[:1500]}"
    info = extract_datetime(text, now, default_time=(17, 0) if category in ("task", "urgent") else (10, 0))
    if info["start"]:
        hours = (info["start"] - now).total_seconds() / 3600
    else:
        hours = 12 if category == "urgent" else 168   # urgent mail without a date still needs attention soon
    if isinstance(received_at, str):
        try:
            received_at = datetime.fromisoformat(received_at)
        except ValueError:
            received_at = None
    waiting = (now - received_at).total_seconds() / 3600 if received_at else 0
    importance = sender_importance(sender)
    score, fired = fuzzy_priority(hours, importance, max(waiting, 0))
    return {"score": round(score, 1), "label": priority_label(score), "fired": fired,
            "inputs": {"deadline_hours": round(hours, 1), "importance": importance, "waiting_hours": round(max(waiting, 0), 1)}}
