RULES = {
    "meeting": ["meeting", "schedule", "call", "appointment", "zoom", "meet"],
    "urgent": ["urgent", "asap", "immediately", "deadline", "important"],
    "task": ["please submit", "assignment", "due", "reminder", "task"],
    "spam": ["unsubscribe", "offer", "discount", "sale", "% off", "newsletter",
             "promotion", "recommendations"],
}

# pehle jo category match ho wohi lagegi, is order mein check hota hai
ORDER = ["spam", "meeting", "urgent", "task"]

def categorize(sender: str, subject: str, body: str) -> str:
    text = f"{sender} {subject} {body}".lower()
    for cat in ORDER:
        if any(k in text for k in RULES[cat]):
            return cat
    return "general"