"""The AutoAssist workflow as functions that always work for ONE user (user_id), used by the dashboard."""
import os
import time
from datetime import datetime, timedelta
from email.utils import parseaddr

from dotenv import load_dotenv
from sqlalchemy import text

from app import calendar_service, gmail_service
from app.accounts import get_user
from app.classifier import classify
from app.db import engine
from app.extract import detect_intent, extract_datetime
from app.fuzzy import priority_label, reminder_interval
from app.llm import LLMError
from app.priority import email_priority
from app.reminders import add_reminder
from app.reply_writer import write_reply
from app.scheduler_rules import check_slot, suggest_slots
from app.search import ALGORITHMS, SlotProblem, search
from app.templates import make_reply

load_dotenv()


def _env_int(name, default):
    """Reads a whole number from .env. A blank or wrong value falls back to the default instead of crashing."""
    try:
        return int((os.getenv(name) or "").strip() or default)
    except ValueError:
        return default


def _env_float(name, default):
    try:
        return float((os.getenv(name) or "").strip() or default)
    except ValueError:
        return default


def _my_name(user_id):
    """The signature of every reply is the name of the account owner (Settings page), not a name from .env."""
    u = get_user(user_id)
    return (u["name"] if u else "") or os.getenv("MY_NAME", "")


def _log(conn, user_id, action, details=""):
    conn.execute(text("INSERT INTO ActivityLog (user_id, action, details) VALUES (:u, :a, :d)"),
                 {"u": user_id, "a": action, "d": details})


def _processed_ids(user_id, action):
    """Email ids this user already handled (stored as 'email N' in the activity log)."""
    with engine.connect() as conn:
        rows = conn.execute(text("SELECT details FROM ActivityLog WHERE user_id = :u AND action = :a"),
                            {"u": user_id, "a": action}).fetchall()
    ids = set()
    for (d,) in rows:
        parts = (d or "").split()
        if len(parts) >= 2 and parts[0] == "email" and parts[1].rstrip(":").isdigit():
            ids.add(int(parts[1].rstrip(":")))
    return ids


# ------------------------------------------------------------------ 1. inbox
def sync_inbox(user_id, max_results=20):
    """Fetches the newest emails of this user, classifies and scores them, stores the new ones."""
    emails = gmail_service.fetch_recent(max_results, user_id=user_id)
    new = ml = 0
    with engine.begin() as conn:
        for e in emails:
            if conn.execute(text("SELECT 1 FROM Emails WHERE gmail_id = :g"), {"g": e["gmail_id"]}).first():
                continue
            category, confidence, method = classify(e["sender"], e["subject"], e["body"])
            priority = email_priority(e["sender"], e["subject"], e["body"], category, e["received_at"])["score"]
            conn.execute(text("""INSERT INTO Emails (user_id, gmail_id, thread_id, sender, subject, body, received_at,
                                                     category, confidence, classified_by, priority_score, status)
                                 VALUES (:u, :gmail_id, :thread_id, :sender, :subject, :body, :received_at,
                                         :category, :confidence, :method, :priority, 'new')"""),
                         {**e, "u": user_id, "category": category, "confidence": confidence,
                          "method": method, "priority": priority})
            new += 1
            ml += method == "ml"
        _log(conn, user_id, "fetch_emails", f"{new} new emails saved ({ml} classified by ML)")
    return {"fetched": len(emails), "new": new, "ml": ml}


# ------------------------------------------------------------------ 2. drafts
def generate_drafts(user_id, max_llm=None, pause=1.5):
    """Writes reply drafts for this user's new emails (AI first, templates as a fallback)."""
    max_llm = _env_int("MAX_DRAFTS_PER_RUN", 10) if max_llm is None else max_llm
    if max_llm < 1:
        max_llm = 10
    with engine.connect() as conn:
        rows = conn.execute(text("""SELECT email_id, sender, subject, body, category FROM Emails
                                    WHERE user_id = :u AND status = 'new' ORDER BY email_id"""), {"u": user_id}).fetchall()
    my_name = _my_name(user_id)
    busy, notes = None, []
    if any(r.category == "meeting" for r in rows):
        try:
            busy = calendar_service.get_busy(21, user_id=user_id)
        except Exception as exc:
            notes.append(f"Calendar not available, replies will not mention free slots ({exc}).")
    llm_ok, llm_count, made, left = True, 0, 0, 0
    skipped_spam = skipped_noreply = skipped_other = 0
    with engine.begin() as conn:
        for r in rows:
            sender = r.sender or ""
            is_noreply = "noreply" in sender.lower() or "no-reply" in sender.lower()
            if r.category == "spam" or is_noreply:
                skipped_spam += r.category == "spam"
                skipped_noreply += r.category != "spam" and is_noreply
                conn.execute(text("UPDATE Emails SET status='ignored' WHERE email_id=:i AND user_id=:u"),
                             {"i": r.email_id, "u": user_id})
                continue
            reply, method = None, "template"
            if llm_ok:
                if llm_count >= max_llm:
                    left += 1
                    continue
                try:
                    reply = write_reply(sender, r.subject, r.body, r.category, busy, my_name)
                    method = "llm"
                    llm_count += 1
                    time.sleep(pause)
                except LLMError as exc:
                    notes.append(f"AI reply failed, templates were used instead. Reason: {exc}")
                    llm_ok = False
            if reply is None:
                reply = make_reply(r.category, sender, my_name)
            if reply is None:
                skipped_other += 1
                conn.execute(text("UPDATE Emails SET status='ignored' WHERE email_id=:i AND user_id=:u"),
                             {"i": r.email_id, "u": user_id})
                continue
            conn.execute(text("""INSERT INTO Drafts (user_id, email_id, reply_text, status, generated_by)
                                 VALUES (:u, :i, :r, 'pending', :g)"""),
                         {"u": user_id, "i": r.email_id, "r": reply, "g": method})
            conn.execute(text("UPDATE Emails SET status='drafted' WHERE email_id=:i AND user_id=:u"),
                         {"i": r.email_id, "u": user_id})
            made += 1
        _log(conn, user_id, "generate_drafts", f"{made} drafts created ({llm_count} by AI)")
    return {"made": made, "llm": llm_count, "templates": made - llm_count, "left": left, "notes": notes,
            "considered": len(rows), "skipped_spam": int(skipped_spam), "skipped_noreply": int(skipped_noreply),
            "skipped_other": skipped_other}


def draft_for_email(user_id, email_id):
    """Writes a reply for ONE email, even if it was skipped before (promotional, no-reply...). The user decides."""
    with engine.connect() as conn:
        e = conn.execute(text("""SELECT email_id, sender, subject, body, category, status FROM Emails
                                 WHERE email_id = :i AND user_id = :u"""), {"i": email_id, "u": user_id}).first()
        existing = conn.execute(text("""SELECT draft_id FROM Drafts
                                        WHERE email_id = :i AND user_id = :u AND status = 'pending'"""),
                                {"i": email_id, "u": user_id}).first()
    if e is None:
        raise ValueError("Email not found.")
    if e.status == "replied":
        raise ValueError("You already replied to this email.")
    if existing:
        return {"draft_id": existing[0], "method": "existing", "note": None}
    was_spam = e.category in (None, "spam")
    category = "general" if was_spam else e.category
    busy = None
    if category == "meeting":
        try:
            busy = calendar_service.get_busy(21, user_id=user_id)
        except Exception:
            busy = None
    my_name = _my_name(user_id)
    method, note = "llm", None
    try:
        reply = write_reply(e.sender or "", e.subject, e.body, category, busy, my_name)
    except LLMError as exc:
        reply, method = make_reply(category, e.sender or "", my_name), "template"
        note = f"The AI could not write this reply ({exc}). A simple template reply was written instead."
    with engine.begin() as conn:
        conn.execute(text("""INSERT INTO Drafts (user_id, email_id, reply_text, status, generated_by)
                             VALUES (:u, :i, :r, 'pending', :g)"""), {"u": user_id, "i": email_id, "r": reply, "g": method})
        if was_spam:     # the user wants a reply, so this email is not promotional after all
            conn.execute(text("UPDATE Emails SET status='drafted', category='general', classified_by='user' WHERE email_id=:i AND user_id=:u"),
                         {"i": email_id, "u": user_id})
        else:
            conn.execute(text("UPDATE Emails SET status='drafted' WHERE email_id=:i AND user_id=:u"), {"i": email_id, "u": user_id})
        _log(conn, user_id, "draft_for_email", f"email {email_id} ({method})")
    return {"draft_id": None, "method": method, "note": note}


def list_emails(user_id, category=None, limit=20):
    """Newest emails first. Returns (rows, total_matching)."""
    with engine.connect() as conn:
        rows = conn.execute(text("""SELECT email_id, received_at, sender, subject, category, priority_score, status
                                    FROM Emails WHERE user_id = :u"""), {"u": user_id}).fetchall()
    if category:
        rows = [r for r in rows if (r.category or "general") == category]
    rows.sort(key=lambda r: (r.received_at is not None, r.received_at or ""), reverse=True)
    return rows[:limit], len(rows)


def pending_email_ids(user_id):
    with engine.connect() as conn:
        return {r[0] for r in conn.execute(text("SELECT email_id FROM Drafts WHERE user_id = :u AND status = 'pending'"),
                                           {"u": user_id})}


def email_summary(user_id):
    """Counts that explain why there may be no drafts."""
    with engine.connect() as conn:
        rows = conn.execute(text("SELECT status, category FROM Emails WHERE user_id = :u"), {"u": user_id}).fetchall()
    return {"total": len(rows), "waiting": sum(r.status == "new" for r in rows),
            "skipped": sum(r.status == "ignored" for r in rows),
            "drafted": sum(r.status == "drafted" for r in rows), "replied": sum(r.status == "replied" for r in rows)}


def pending_drafts(user_id):
    with engine.connect() as conn:
        rows = conn.execute(text("""SELECT d.draft_id, d.reply_text, d.generated_by, e.email_id, e.sender, e.subject,
                                           e.thread_id, e.category, e.priority_score
                                    FROM Drafts d JOIN Emails e ON e.email_id = d.email_id
                                    WHERE d.user_id = :u AND d.status = 'pending'"""), {"u": user_id}).fetchall()
    return sorted(rows, key=lambda r: (-(r.priority_score or 0), r.draft_id))


def approve_draft(user_id, draft_id, reply_text):
    with engine.connect() as conn:
        d = conn.execute(text("""SELECT d.draft_id, e.email_id, e.sender, e.subject, e.thread_id
                                 FROM Drafts d JOIN Emails e ON e.email_id = d.email_id
                                 WHERE d.draft_id = :d AND d.user_id = :u AND d.status = 'pending'"""),
                         {"d": draft_id, "u": user_id}).first()
    if d is None:
        raise ValueError("Draft not found.")
    gmail_service.send_reply(d.sender, d.subject, reply_text, d.thread_id, user_id=user_id)
    with engine.begin() as conn:
        conn.execute(text("UPDATE Drafts SET status='sent', reply_text=:r, sent_at=:n WHERE draft_id=:d AND user_id=:u"),
                     {"r": reply_text, "n": datetime.now(), "d": draft_id, "u": user_id})
        conn.execute(text("UPDATE Emails SET status='replied' WHERE email_id=:i AND user_id=:u"),
                     {"i": d.email_id, "u": user_id})
        _log(conn, user_id, "send_reply", f"draft {draft_id}")


def reject_draft(user_id, draft_id):
    with engine.begin() as conn:
        d = conn.execute(text("SELECT email_id FROM Drafts WHERE draft_id=:d AND user_id=:u AND status='pending'"),
                         {"d": draft_id, "u": user_id}).first()
        if d is None:
            raise ValueError("Draft not found.")
        conn.execute(text("UPDATE Drafts SET status='rejected' WHERE draft_id=:d AND user_id=:u"), {"d": draft_id, "u": user_id})
        conn.execute(text("UPDATE Emails SET status='rejected' WHERE email_id=:i AND user_id=:u"), {"i": d[0], "u": user_id})
        _log(conn, user_id, "reject_draft", f"draft {draft_id}")


# ------------------------------------------------------------------ 3. meetings
def meeting_requests(user_id, busy, now=None):
    """Meeting emails that still need a decision, each with the search-based slot options."""
    now = now or datetime.now()
    algo = os.getenv("SEARCH_ALGORITHM", "astar").strip().lower()
    algo = algo if algo in ALGORITHMS else "astar"
    w = _env_float("WASTAR_W", 2.0)
    with engine.connect() as conn:
        rows = conn.execute(text("""SELECT email_id, sender, subject, body FROM Emails
                                    WHERE user_id = :u AND category = 'meeting' ORDER BY email_id"""), {"u": user_id}).fetchall()
        booked = {r[0] for r in conn.execute(text("SELECT email_id FROM Meetings WHERE user_id = :u"), {"u": user_id}) if r[0]}
    skip = booked | _processed_ids(user_id, "meeting_noted")
    items = []
    for r in rows:
        if r.email_id in skip:
            continue
        body_text = f"{r.subject or ''}. {(r.body or '')[:1500]}"
        intent, info = detect_intent(body_text), extract_datetime(body_text, now)
        dur = info["duration_min"]
        item = {"email_id": r.email_id, "sender": r.sender, "subject": r.subject, "intent": intent, "duration": dur,
                "requested": info["start"], "approx": info["approx"], "message": "", "options": [], "effort": [], "algo": ALGORITHMS[algo]}
        if intent in ("cancel", "confirm"):
            item["message"] = f"This is a '{intent}' message, so no new event is needed."
        elif info["start"]:
            ok, why = check_slot(busy, info["start"], dur, now)
            if ok:
                item["message"] = "The requested time is free. No search was needed."
                item["options"].append((info["start"], info["start"] + timedelta(minutes=dur), "requested time (free)"))
            else:
                item["message"] = f"The requested time is not available: {why}."
                problem = SlotProblem(busy, info["start"], dur, now)
                results = {a: search(problem, a, k=3, w=w) for a in ALGORITHMS}
                item["effort"] = list(results.values())
                chosen = results[algo]
                item["options"] = [(a, b, f"{chosen['label']} search") for a, b in chosen["slots"]]
        else:
            item["message"] = "No date or time was found in the email. These are the earliest free slots."
            item["options"] = [(a, b, "first-fit") for a, b in suggest_slots(busy, dur, n=3)]
        items.append(item)
    return items


def book_meeting(user_id, item, option_index):
    start, end, how = item["options"][option_index]
    calendar_service.create_event(item["subject"] or "Meeting", start, end, f"Requested by {item['sender']}", user_id=user_id)
    with engine.begin() as conn:
        conn.execute(text("""INSERT INTO Meetings (user_id, email_id, title, start_time, end_time, participants, algorithm_used)
                             VALUES (:u, :i, :t, :s, :e, :p, :a)"""),
                     {"u": user_id, "i": item["email_id"], "t": item["subject"] or "Meeting", "s": start, "e": end,
                      "p": item["sender"], "a": how})
        for r in item["effort"]:
            conn.execute(text("""INSERT INTO AlgorithmRuns (algorithm, states_expanded, time_ms, result_quality)
                                 VALUES (:a, :s, :t, :q)"""),
                         {"a": r["label"], "s": r["expanded"], "t": r["time_ms"], "q": r["shift_min"]})
        _log(conn, user_id, "schedule_meeting", f"email {item['email_id']} at {start} ({how})")


def note_meeting(user_id, email_id, why):
    with engine.begin() as conn:
        _log(conn, user_id, "meeting_noted", f"email {email_id}")
        _log(conn, user_id, "meeting_skipped", f"email {email_id}: {why}")


# ------------------------------------------------------------------ 4. reminders from emails
def reminder_suggestions(user_id, now=None):
    now = now or datetime.now()
    with engine.connect() as conn:
        rows = conn.execute(text("""SELECT email_id, sender, subject, body, category, received_at FROM Emails
                                    WHERE user_id = :u AND category IN ('task', 'urgent') ORDER BY email_id"""),
                            {"u": user_id}).fetchall()
    done = _processed_ids(user_id, "reminder_from_email")
    out = []
    for r in rows:
        if r.email_id in done:
            continue
        info = extract_datetime(f"{r.subject or ''}. {(r.body or '')[:1500]}", now, default_time=(17, 0))
        if not info["start"] or info["start"] <= now:
            continue
        score = email_priority(r.sender, r.subject, r.body, r.category, r.received_at, now)["score"]
        hours = (info["start"] - now).total_seconds() / 3600
        who = parseaddr(r.sender)[0] or parseaddr(r.sender)[1]
        out.append({"email_id": r.email_id, "title": f"{r.subject or 'Task'} (from {who})"[:250], "deadline": info["start"],
                    "approx": info["approx"], "score": score, "label": priority_label(score),
                    "interval": reminder_interval(hours, score)})
    return out


def create_reminder_from_email(user_id, s):
    add_reminder(s["title"], s["deadline"], priority=s["score"], frequency_minutes=s["interval"], user_id=user_id)
    with engine.begin() as conn:
        _log(conn, user_id, "reminder_from_email", f"email {s['email_id']}")


def decline_reminder_suggestion(user_id, email_id):
    with engine.begin() as conn:
        _log(conn, user_id, "reminder_from_email", f"email {email_id}")
        _log(conn, user_id, "reminder_decision", f"email {email_id}: declined")


# ------------------------------------------------------------------ 5. privacy
def delete_user_data(user_id):
    """Removes everything stored about this user's mailbox (the login account itself stays)."""
    with engine.begin() as conn:
        for table in ("Drafts", "Meetings", "Reminders", "Emails", "ActivityLog", "UserTokens", "OAuthStates"):
            conn.execute(text(f"DELETE FROM {table} WHERE user_id = :u"), {"u": user_id})
