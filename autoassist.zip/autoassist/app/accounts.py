"""User accounts: registration, login with lock-out, password change."""
import hmac
import os
import re
from datetime import datetime, timedelta

import bcrypt
from dotenv import load_dotenv
from sqlalchemy import text

from app.db import engine

load_dotenv()
EMAIL_RE = re.compile(r"^[^@\s]+@[^@\s]+\.[^@\s]+$")
MAX_FAILS, LOCK_MINUTES = 5, 10
_DUMMY = bcrypt.hashpw(b"dummy-password", bcrypt.gensalt())   # keeps login timing similar for unknown emails


class AccountError(Exception):
    pass


def registration_code_required():
    return bool(os.getenv("REGISTRATION_CODE", "").strip())


def _check_password_rules(password):
    if len(password) < 8:
        raise AccountError("Password must be at least 8 characters.")
    if len(password.encode()) > 72:
        raise AccountError("Password is too long (maximum 72 characters).")


def _to_dt(v):
    if isinstance(v, str):
        try:
            return datetime.fromisoformat(v)
        except ValueError:
            return None
    return v


def create_user(name, email, password, role="user", code=None, check_code=True):
    name, email = (name or "").strip(), (email or "").strip().lower()
    if not 2 <= len(name) <= 60:
        raise AccountError("Please enter your full name (2 to 60 characters).")
    if not EMAIL_RE.match(email) or len(email) > 254:
        raise AccountError("Please enter a valid email address.")
    _check_password_rules(password or "")
    if check_code and registration_code_required():
        if not hmac.compare_digest((code or "").strip(), os.getenv("REGISTRATION_CODE").strip()):
            raise AccountError("Invalid registration code.")
    hashed = bcrypt.hashpw(password.encode(), bcrypt.gensalt()).decode()
    with engine.begin() as conn:
        if conn.execute(text("SELECT 1 FROM Users WHERE email = :e"), {"e": email}).first():
            raise AccountError("An account with this email already exists.")
        conn.execute(text("""INSERT INTO Users (name, email, password_hash, role, failed_attempts)
                             VALUES (:n, :e, :p, :r, 0)"""), {"n": name, "e": email, "p": hashed, "r": role})
        return conn.execute(text("SELECT user_id FROM Users WHERE email = :e"), {"e": email}).first()[0]


def authenticate(email, password):
    """Returns {'user_id','name','email','role'} or raises AccountError. Locks the account after 5 wrong passwords."""
    email, password = (email or "").strip().lower(), password or ""
    now = datetime.now()
    outcome, user, message = "bad", None, "Invalid email or password."
    with engine.begin() as conn:
        row = conn.execute(text("""SELECT user_id, name, email, password_hash, role, failed_attempts, locked_until
                                   FROM Users WHERE email = :e"""), {"e": email}).first()
        if row is None or len(password.encode()) > 72:
            bcrypt.checkpw(b"x", _DUMMY)
        else:
            locked = _to_dt(row.locked_until)
            if locked and locked > now:
                mins = int((locked - now).total_seconds() // 60) + 1
                outcome, message = "locked", f"Too many failed attempts. Try again in {mins} minute(s)."
            elif bcrypt.checkpw(password.encode(), row.password_hash.encode()):
                conn.execute(text("UPDATE Users SET failed_attempts = 0, locked_until = NULL WHERE user_id = :u"),
                             {"u": row.user_id})
                outcome = "ok"
                user = {"user_id": row.user_id, "name": row.name, "email": row.email, "role": row.role}
            else:
                fails = (row.failed_attempts or 0) + 1
                if fails >= MAX_FAILS:
                    conn.execute(text("UPDATE Users SET failed_attempts = 0, locked_until = :l WHERE user_id = :u"),
                                 {"l": now + timedelta(minutes=LOCK_MINUTES), "u": row.user_id})
                else:
                    conn.execute(text("UPDATE Users SET failed_attempts = :f WHERE user_id = :u"),
                                 {"f": fails, "u": row.user_id})
    if outcome != "ok":
        raise AccountError(message)
    return user


def change_password(user_id, old_password, new_password):
    _check_password_rules(new_password or "")
    with engine.connect() as conn:
        row = conn.execute(text("SELECT password_hash FROM Users WHERE user_id = :u"), {"u": user_id}).first()
    if row is None or len((old_password or "").encode()) > 72 or not bcrypt.checkpw(old_password.encode(), row[0].encode()):
        raise AccountError("Current password is wrong.")
    hashed = bcrypt.hashpw(new_password.encode(), bcrypt.gensalt()).decode()
    with engine.begin() as conn:
        conn.execute(text("UPDATE Users SET password_hash = :p WHERE user_id = :u"), {"p": hashed, "u": user_id})


def update_name(user_id, name):
    """The name shown in the dashboard and used to sign reply drafts."""
    name = (name or "").strip()
    if not 2 <= len(name) <= 60:
        raise AccountError("Please enter your full name (2 to 60 characters).")
    with engine.begin() as conn:
        conn.execute(text("UPDATE Users SET name = :n WHERE user_id = :u"), {"n": name, "u": user_id})
    return name


def get_user(user_id):
    with engine.connect() as conn:
        row = conn.execute(text("SELECT user_id, name, email, role FROM Users WHERE user_id = :u"), {"u": user_id}).first()
    return {"user_id": row.user_id, "name": row.name, "email": row.email, "role": row.role} if row else None


def default_user_id():
    """Used by old single-user scripts: the first account that was ever created."""
    with engine.connect() as conn:
        row = conn.execute(text("SELECT user_id FROM Users ORDER BY user_id")).first()
    if row is None:
        raise AccountError("No user accounts exist yet. Run create_user.py first.")
    return row[0]
