"""Meeting-slot scheduling as a SEARCH problem: BFS, DFS, A* and Weighted A*.

State  : a time slot on a 30-minute grid (stored as an integer index).
Start  : the time the sender asked for.
Action : move to the next slot (+30 min) or the previous slot (-30 min). Every move costs 30 (minutes of shift).
Goal   : a slot where the meeting fits: free in the calendar, working hours, not lunch, not weekend, not in the past.
g(n)   : total shift (minutes) from the requested time.
h(n)   : minutes to the nearest slot that satisfies the STATIC rules (hours, lunch, weekend, past), ignoring the
         calendar. Relaxing a problem never makes the answer cheaper, so h never over-estimates (admissible),
         and because one move changes it by at most 30, it is also consistent.
"""
import heapq
import itertools
import time
from bisect import bisect_left
from collections import deque
from datetime import datetime, timedelta

from app.calendar_service import PKT
from app.scheduler_rules import STEP, check_slot, overlaps

ALGORITHMS = {"bfs": "BFS", "dfs": "DFS", "astar": "A*", "wastar": "Weighted A*"}


class SlotProblem:
    def __init__(self, busy, target, duration_min=60, now=None, horizon_days=14):
        self.busy, self.dur, self.target = busy, duration_min, target
        self.now = now or datetime.now(PKT).replace(tzinfo=None)
        self.step = timedelta(minutes=STEP)
        steps_per_day = 24 * 60 // STEP
        start = target.replace(second=0, microsecond=0)
        start = start.replace(minute=(start.minute // STEP) * STEP)
        self.lo = start - timedelta(days=horizon_days)
        self.n = 2 * horizon_days * steps_per_day + 1
        self.s0 = horizon_days * steps_per_day                      # index of the start state
        self.grid = [self.lo + i * self.step for i in range(self.n)]
        # static feasibility of every slot (relaxed problem: calendar ignored), computed once
        self.static_idx = [i for i, t in enumerate(self.grid) if check_slot([], t, duration_min, self.now)[0]]
        self._goal, self._h = {}, {}

    def neighbors(self, i):
        out = []
        if i + 1 < self.n:
            out.append(i + 1)
        if i - 1 >= 0:
            out.append(i - 1)
        return out

    def is_goal(self, i):
        if i not in self._goal:
            t = self.grid[i]
            end = t + timedelta(minutes=self.dur)
            self._goal[i] = (self._static(i) and not any(overlaps(t, end, bs, be) for bs, be in self.busy))
        return self._goal[i]

    def _static(self, i):
        j = bisect_left(self.static_idx, i)
        return j < len(self.static_idx) and self.static_idx[j] == i

    def h(self, i):
        if i not in self._h:
            j = bisect_left(self.static_idx, i)
            cands = []
            if j < len(self.static_idx):
                cands.append(self.static_idx[j] - i)
            if j > 0:
                cands.append(i - self.static_idx[j - 1])
            self._h[i] = min(cands) * STEP if cands else self.n * STEP
        return self._h[i]

    def slot(self, i):
        return self.grid[i], self.grid[i] + timedelta(minutes=self.dur)


def _bfs(p, k):
    queue, seen, goals, expanded = deque([p.s0]), {p.s0}, [], 0
    while queue and len(goals) < k:
        i = queue.popleft()
        expanded += 1
        if p.is_goal(i):
            goals.append(i)
        for j in p.neighbors(i):
            if j not in seen:
                seen.add(j)
                queue.append(j)
    return goals, expanded


def _dfs(p, k):
    stack, seen, goals, expanded = [p.s0], set(), [], 0
    while stack and len(goals) < k:
        i = stack.pop()
        if i in seen:
            continue
        seen.add(i)
        expanded += 1
        if p.is_goal(i):
            goals.append(i)
        for j in reversed(p.neighbors(i)):   # the later slot is explored first
            if j not in seen:
                stack.append(j)
    return goals, expanded


def _astar(p, k, w=1.0):
    counter = itertools.count()
    open_ = [(w * p.h(p.s0), 0, next(counter), p.s0)]       # (f, -g, tie-breaker, state)
    g_best, closed, goals, expanded = {p.s0: 0}, set(), [], 0
    while open_ and len(goals) < k:
        _, neg_g, _, i = heapq.heappop(open_)
        g = -neg_g
        if i in closed or g > g_best[i]:
            continue
        closed.add(i)
        expanded += 1
        if p.is_goal(i):
            goals.append(i)
        for j in p.neighbors(i):
            ng = g + STEP
            if ng < g_best.get(j, float("inf")):
                g_best[j] = ng
                closed.discard(j)
                heapq.heappush(open_, (ng + w * p.h(j), -ng, next(counter), j))
    return goals, expanded


def search(problem, algorithm="astar", k=3, w=2.0):
    """Runs one algorithm. Returns slots, states expanded, time and the shift of the best slot found."""
    t0 = time.perf_counter()
    if algorithm == "bfs":
        goals, expanded = _bfs(problem, k)
    elif algorithm == "dfs":
        goals, expanded = _dfs(problem, k)
    elif algorithm == "astar":
        goals, expanded = _astar(problem, k, 1.0)
    elif algorithm == "wastar":
        goals, expanded = _astar(problem, k, w)
    else:
        raise ValueError(f"Unknown algorithm '{algorithm}' (use bfs, dfs, astar or wastar)")
    ms = (time.perf_counter() - t0) * 1000
    slots = [problem.slot(i) for i in goals]
    shifts = [abs((s - problem.target).total_seconds()) / 60 for s, _ in slots]
    return {"algorithm": algorithm, "label": ALGORITHMS[algorithm] + (f" (w={w:g})" if algorithm == "wastar" else ""),
            "slots": sorted(slots), "expanded": expanded, "time_ms": round(ms, 3),
            "shift_min": min(shifts) if shifts else None, "found": len(slots)}


def find_slots(busy, target, duration_min=60, algorithm="astar", k=3, w=2.0, now=None):
    return search(SlotProblem(busy, target, duration_min, now), algorithm, k, w)
