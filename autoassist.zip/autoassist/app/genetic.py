"""Genetic Algorithm that plans a whole week: many meetings and tasks are placed at the same time.

Chromosome : one gene per item = the start slot it gets (an index into the list of usable 30-minute slots),
             or -1 = 'not scheduled'. Only slots where the item fits inside a work segment (before lunch / after lunch)
             are allowed, so no gene can run through lunch or past 5 PM.
Fitness    : a COST to minimise = heavy penalties for overlaps (with other items or with your calendar), missed task
             deadlines and unscheduled items, plus soft penalties for moving a meeting away from the time that was
             requested, putting important things late, overloaded days and back-to-back items.
             The importance of an item is its fuzzy-logic priority (0-100).
Operators  : tournament selection, uniform crossover, three mutations (local shift, random slot, swap) and elitism.
Baselines  : Greedy (best-first placement) and Random search with the same number of evaluations.
"""
import random
import time
from dataclasses import dataclass, field
from datetime import datetime, timedelta

STEP = 30
WORK_START, LUNCH_START, LUNCH_END, WORK_END = 9, 13, 14, 17

# cost weights (minutes are the unit of time)
W_OVERLAP = 40.0      # per minute two items overlap
W_BUSY = 50.0         # per minute an item overlaps an event that is already in the calendar
W_LATE = 1.5          # per minute a task ends after its deadline (x importance)
W_UNSCHED = 600.0     # leaving an item out (x importance)
W_PREF = 0.4          # per minute a meeting is moved away from the requested time (x importance)
W_DELAY = 2.0         # per hour an item is placed later in the week (x importance)
W_LOAD = 30.0         # per hour above 5 busy hours in one day
W_B2B = 4.0           # per pair of items that touch with no break


@dataclass
class Item:
    id: int
    title: str
    kind: str                       # "meeting" or "task"
    duration: int                   # minutes
    priority: float = 50.0          # 0-100 (fuzzy priority)
    preferred: datetime = None      # requested start (meetings)
    deadline: datetime = None       # latest end (tasks)
    meta: dict = field(default_factory=dict)


def _ceil_step(m):
    return max(STEP, -(-int(m) // STEP) * STEP)


class Problem:
    def __init__(self, items, busy, now, days=5):
        self.items, self.now, self.days = list(items), now, days
        self.origin = now.replace(hour=0, minute=0, second=0, microsecond=0)
        self.slots = self._build_slots()
        self.abs = [self._m(t) for t in self.slots]
        self.dur = [_ceil_step(it.duration) for it in self.items]
        self.allowed = [[s for s, t in enumerate(self.slots) if t + timedelta(minutes=d) <= self._segment_end(t)]
                        for d in self.dur]
        self.pos = [{s: k for k, s in enumerate(a)} for a in self.allowed]
        last = self.slots[-1] + timedelta(minutes=STEP) if self.slots else now
        self.busy_abs = [(self._m(s), self._m(e)) for s, e in busy if e > now and s < last]
        self.pref_abs = [self._m(it.preferred) if it.preferred else None for it in self.items]
        self.deadline_abs = [self._m(it.deadline) if it.deadline else None for it in self.items]
        self.t0 = self._m(now)
        self.evaluations = 0

    # ---- slots
    def _m(self, t):
        return (t - self.origin).total_seconds() / 60

    def _segment_end(self, t):
        return t.replace(hour=LUNCH_START if t.hour < LUNCH_START else WORK_END, minute=0, second=0, microsecond=0)

    def _build_slots(self):
        slots, d, added = [], 0, 0
        while added < self.days:
            day = self.origin + timedelta(days=d)
            d += 1
            if day.weekday() >= 5:
                continue
            added += 1
            for a, b in ((WORK_START, LUNCH_START), (LUNCH_END, WORK_END)):
                t, end = day.replace(hour=a), day.replace(hour=b)
                while t < end:
                    if t > self.now + timedelta(minutes=30):
                        slots.append(t)
                    t += timedelta(minutes=STEP)
        return slots

    # ---- cost
    def cost(self, genes, detail=False):
        self.evaluations += 1
        total = 0.0
        iv, busy_hit, late_min, missed, unsched, shift_sum, shift_n = [], 0, 0.0, 0, 0, 0.0, 0
        for i, g in enumerate(genes):
            it = self.items[i]
            w = it.priority / 100.0
            if g < 0:
                total += W_UNSCHED * (1 + w / 2)
                unsched += 1
                continue
            s = self.abs[g]
            e = s + self.dur[i]
            iv.append((s, e, i))
            hit = False
            for bs, be in self.busy_abs:
                o = min(e, be) - max(s, bs)
                if o > 0:
                    total += W_BUSY * o
                    hit = True
            busy_hit += hit
            if self.pref_abs[i] is not None:
                shift = abs(s - self.pref_abs[i])
                total += W_PREF * shift * (0.5 + w)
                shift_sum += shift
                shift_n += 1
            if self.deadline_abs[i] is not None and e > self.deadline_abs[i]:
                late = e - self.deadline_abs[i]
                total += W_LATE * late * (1 + w)
                late_min += late
                missed += 1
            total += W_DELAY * ((s - self.t0) / 60.0) * w
        iv.sort()
        pair_conf, load, b2b = 0, {}, 0
        for k in range(len(iv)):
            s, e, _ = iv[k]
            day = int(s // 1440)
            load[day] = load.get(day, 0) + (e - s)
            for j in range(k + 1, len(iv)):
                if iv[j][0] >= e:
                    break
                total += W_OVERLAP * (min(e, iv[j][1]) - iv[j][0])
                pair_conf += 1
            if k + 1 < len(iv) and iv[k + 1][0] == e and int(iv[k + 1][0] // 1440) == day:
                b2b += 1
        total += W_B2B * b2b
        for minutes in load.values():
            if minutes > 300:
                total += W_LOAD * (minutes - 300) / 60.0
        if not detail:
            return total
        return total, {"conflicts": pair_conf + busy_hit, "missed_deadlines": missed, "late_minutes": late_min,
                       "unscheduled": unsched, "avg_shift_min": (shift_sum / shift_n) if shift_n else 0.0, "back_to_back": b2b}

    # ---- readable plan
    def describe(self, genes):
        rows = []
        for i, g in enumerate(genes):
            it = self.items[i]
            row = {"id": it.id, "title": it.title, "kind": it.kind, "priority": it.priority, "duration": self.dur[i], "meta": it.meta}
            if g < 0:
                row.update(start=None, end=None, note="could not be scheduled")
            else:
                s = self.slots[g]
                e = s + timedelta(minutes=self.dur[i])
                notes = []
                if it.preferred is not None:
                    d = round(abs((s - it.preferred).total_seconds()) / 60)
                    notes.append("at the requested time" if d == 0 else f"{d} min from the requested time")
                if it.deadline is not None:
                    notes.append("before the deadline" if e <= it.deadline else "AFTER the deadline")
                row.update(start=s, end=e, note="; ".join(notes))
            rows.append(row)
        return sorted(rows, key=lambda r: (r["start"] is None, r["start"] or self.now))


# ------------------------------------------------------------------ algorithms
def _random_individual(p, rng):
    return [(-1 if (not p.allowed[i] or rng.random() < 0.03) else rng.choice(p.allowed[i])) for i in range(len(p.items))]


def run_ga(p, pop_size=80, generations=200, seed=None, patience=60, tournament=3, p_cross=0.9, p_mut=0.12, elite=2):
    t0 = time.perf_counter()
    rng, n = random.Random(seed), len(p.items)
    p.evaluations = 0
    if n == 0:
        return {"genes": [], "cost": 0.0, "history": {"best": [0.0], "avg": [0.0]}, "evaluations": 0, "time_ms": 0.0, "generations": 0}
    pop = [_random_individual(p, rng) for _ in range(pop_size)]
    fit = [p.cost(g) for g in pop]
    best_i = min(range(pop_size), key=fit.__getitem__)
    best, best_cost = pop[best_i][:], fit[best_i]
    hist_best, hist_avg, stale, gen = [best_cost], [sum(fit) / pop_size], 0, 0

    def pick():
        cand = rng.sample(range(pop_size), min(tournament, pop_size))
        return pop[min(cand, key=fit.__getitem__)]

    def mutate(g):
        for i in range(n):
            if not p.allowed[i] or rng.random() >= p_mut:
                continue
            r = rng.random()
            if r < 0.5 and g[i] >= 0:                                   # local shift inside the allowed slots
                k = p.pos[i][g[i]] + rng.choice([-4, -3, -2, -1, 1, 2, 3, 4])
                g[i] = p.allowed[i][max(0, min(len(p.allowed[i]) - 1, k))]
            elif r < 0.8:                                               # any allowed slot
                g[i] = rng.choice(p.allowed[i])
            elif r < 0.93 and n > 1:                                    # swap start times with another item
                j = rng.randrange(n)
                if j != i and g[j] >= 0 and g[j] in p.pos[i] and g[i] in p.pos[j]:
                    g[i], g[j] = g[j], g[i]
            else:                                                       # drop / bring back
                g[i] = -1 if g[i] >= 0 else rng.choice(p.allowed[i])

    for gen in range(1, generations + 1):
        order = sorted(range(pop_size), key=fit.__getitem__)
        new = [pop[k][:] for k in order[:elite]]
        while len(new) < pop_size:
            a, b = pick()[:], pick()[:]
            if rng.random() < p_cross:                                  # uniform crossover
                for i in range(n):
                    if rng.random() < 0.5:
                        a[i], b[i] = b[i], a[i]
            mutate(a)
            mutate(b)
            new.extend([a, b])
        pop = new[:pop_size]
        fit = [p.cost(g) for g in pop]
        i = min(range(pop_size), key=fit.__getitem__)
        if fit[i] < best_cost - 1e-9:
            best, best_cost, stale = pop[i][:], fit[i], 0
        else:
            stale += 1
        hist_best.append(best_cost)
        hist_avg.append(sum(fit) / pop_size)
        if stale >= patience:
            break
    return {"genes": best, "cost": best_cost, "history": {"best": hist_best, "avg": hist_avg},
            "evaluations": p.evaluations, "time_ms": (time.perf_counter() - t0) * 1000, "generations": gen}


def run_greedy(p):
    """Important items first; each one goes to the cheapest slot that does not clash with what is already placed."""
    t0 = time.perf_counter()
    p.evaluations = 0
    n = len(p.items)
    genes = [-1] * n
    order = sorted(range(n), key=lambda i: (-p.items[i].priority, p.items[i].deadline or datetime.max))
    for i in order:
        best_g, best_c = -1, None
        for g in p.allowed[i]:
            genes[i] = g
            c = p.cost(genes)
            if best_c is None or c < best_c:
                best_g, best_c = g, c
        genes[i] = best_g
        unsched = list(genes)
        unsched[i] = -1
        if best_g >= 0 and p.cost(unsched) <= best_c:       # leaving it out is cheaper than any clashing slot
            genes[i] = -1
    cost = p.cost(genes)
    return {"genes": genes, "cost": cost, "evaluations": p.evaluations, "time_ms": (time.perf_counter() - t0) * 1000}


def run_random(p, evaluations, seed=None):
    t0 = time.perf_counter()
    rng = random.Random(seed)
    p.evaluations = 0
    best, best_c = None, float("inf")
    for _ in range(max(1, evaluations)):
        g = _random_individual(p, rng)
        c = p.cost(g)
        if c < best_c:
            best, best_c = g, c
    return {"genes": best or [], "cost": best_c, "evaluations": p.evaluations, "time_ms": (time.perf_counter() - t0) * 1000}


def metrics(p, genes):
    cost, parts = p.cost(genes, detail=True)
    return {"cost": cost, **parts}
