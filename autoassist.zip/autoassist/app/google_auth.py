"""Per-user Google sign-in. Tokens live encrypted in the database (UserTokens), one row per user."""
import json
import os
from datetime import datetime, timedelta

from dotenv import load_dotenv
from google.auth.exceptions import RefreshError
from google.auth.transport.requests import Request
from google.oauth2.credentials import Credentials
from google_auth_oauthlib.flow import Flow
from googleapiclient.discovery import build
from sqlalchemy import text

from app.accounts import default_user_id
from app.db import engine
from app.security import decrypt, encrypt

load_dotenv()
SCOPES = ["https://www.googleapis.com/auth/gmail.readonly",
          "https://www.googleapis.com/auth/gmail.send",
          "https://www.googleapis.com/auth/calendar.events"]
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
CLIENT_FILE = os.getenv("GOOGLE_CLIENT_FILE", os.path.join(ROOT, "credentials", "credentials.json"))
APP_URL = os.getenv("APP_URL", "http://localhost:8501").rstrip("/")
STATE_TTL_MINUTES = 10


class GoogleAuthError(Exception):
    pass


def _flow(code_verifier=None):
    if APP_URL.startswith(("http://localhost", "http://127.0.0.1")):
        os.environ.setdefault("OAUTHLIB_INSECURE_TRANSPORT", "1")   # plain http is fine on your own machine
    os.environ["OAUTHLIB_RELAX_TOKEN_SCOPE"] = "1"                   # we check the granted scopes ourselves
    if not os.path.exists(CLIENT_FILE):
        raise GoogleAuthError("credentials/credentials.json (Google OAuth client) is missing.")
    return Flow.from_client_secrets_file(CLIENT_FILE, scopes=SCOPES, redirect_uri=APP_URL + "/",
                                         code_verifier=code_verifier)


def _to_dt(v):
    return datetime.fromisoformat(v) if isinstance(v, str) else v


def start_oauth(user_id):
    """Returns the Google consent URL for this user. A one-time 'state' ties the answer back to the user."""
    flow = _flow()
    url, state = flow.authorization_url(access_type="offline", prompt="consent", include_granted_scopes="false")
    with engine.begin() as conn:
        conn.execute(text("DELETE FROM OAuthStates WHERE user_id = :u"), {"u": user_id})
        conn.execute(text("INSERT INTO OAuthStates (state, user_id, code_verifier, created_at) VALUES (:s, :u, :v, :c)"),
                     {"s": state, "u": user_id, "v": flow.code_verifier, "c": datetime.now()})
    return url


def finish_oauth(state, code):
    """Google redirected back. Exchanges the code for tokens and stores them encrypted. Returns (user_id, gmail_address)."""
    now = datetime.now()
    with engine.begin() as conn:
        row = conn.execute(text("SELECT user_id, code_verifier, created_at FROM OAuthStates WHERE state = :s"),
                           {"s": state}).first()
        conn.execute(text("DELETE FROM OAuthStates WHERE state = :s"), {"s": state})   # single use
    if row is None or _to_dt(row.created_at) < now - timedelta(minutes=STATE_TTL_MINUTES):
        raise GoogleAuthError("This connection link is invalid or has expired. Please start again from Settings.")
    flow = _flow(row.code_verifier)
    try:
        flow.fetch_token(code=code)
    except Exception as exc:
        raise GoogleAuthError(f"Google did not accept the sign-in: {exc}") from exc
    creds = flow.credentials
    granted = set(getattr(creds, "granted_scopes", None) or creds.scopes or [])
    missing = [s.rsplit("/", 1)[-1] for s in SCOPES if s not in granted]
    if missing:
        raise GoogleAuthError("Please tick ALL permissions on Google's screen (missing: " + ", ".join(missing) + ").")
    try:
        address = build("gmail", "v1", credentials=creds, cache_discovery=False).users().getProfile(userId="me").execute()["emailAddress"]
    except Exception as exc:
        raise GoogleAuthError(f"Connected, but Gmail could not be read: {exc}") from exc
    save_token(row.user_id, creds, address)
    return row.user_id, address


def save_token(user_id, creds, address=None):
    with engine.begin() as conn:
        old = conn.execute(text("SELECT gmail_address FROM UserTokens WHERE user_id = :u"), {"u": user_id}).first()
        address = address or (old[0] if old else None)
        conn.execute(text("DELETE FROM UserTokens WHERE user_id = :u"), {"u": user_id})
        conn.execute(text("""INSERT INTO UserTokens (user_id, gmail_address, token_enc, updated_at)
                             VALUES (:u, :a, :t, :n)"""),
                     {"u": user_id, "a": address, "t": encrypt(creds.to_json()), "n": datetime.now()})


def get_credentials(user_id=None):
    uid = user_id or default_user_id()
    with engine.connect() as conn:
        row = conn.execute(text("SELECT token_enc FROM UserTokens WHERE user_id = :u"), {"u": uid}).first()
    if row is None:
        raise GoogleAuthError("Gmail is not connected for this account. Open Settings and connect it.")
    creds = Credentials.from_authorized_user_info(json.loads(decrypt(row[0])), SCOPES)
    if not creds.valid and creds.refresh_token:
        try:
            creds.refresh(Request())
        except RefreshError as exc:
            raise GoogleAuthError("Your Gmail connection has expired (Google testing mode expires after 7 days). "
                                  "Please reconnect in Settings.") from exc
        save_token(uid, creds)
    return creds


def connection_status(user_id):
    with engine.connect() as conn:
        row = conn.execute(text("SELECT gmail_address, updated_at FROM UserTokens WHERE user_id = :u"), {"u": user_id}).first()
    return {"address": row.gmail_address, "updated_at": _to_dt(row.updated_at)} if row else None


def disconnect(user_id):
    with engine.begin() as conn:
        conn.execute(text("DELETE FROM UserTokens WHERE user_id = :u"), {"u": user_id})
        conn.execute(text("DELETE FROM OAuthStates WHERE user_id = :u"), {"u": user_id})
